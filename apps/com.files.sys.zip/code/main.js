var jt=Object.defineProperty;var qt=Object.getOwnPropertyDescriptor;var l=(n,t,e,i)=>{for(var s=i>1?void 0:i?qt(t,e):t,o=n.length-1,r;o>=0;o--)(r=n[o])&&(s=(i?r(t,e,s):r(s))||s);return i&&s&&jt(t,e,s),s};var G=globalThis,Q=G.ShadowRoot&&(G.ShadyCSS===void 0||G.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,yt=Symbol(),vt=new WeakMap,J=class{constructor(t,e,i){if(this._$cssResult$=!0,i!==yt)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=e}get styleSheet(){let t=this.o,e=this.t;if(Q&&t===void 0){let i=e!==void 0&&e.length===1;i&&(t=vt.get(e)),t===void 0&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),i&&vt.set(e,t))}return t}toString(){return this.cssText}},_t=n=>new J(typeof n=="string"?n:n+"",void 0,yt);var dt=(n,t)=>{if(Q)n.adoptedStyleSheets=t.map(e=>e instanceof CSSStyleSheet?e:e.styleSheet);else for(let e of t){let i=document.createElement("style"),s=G.litNonce;s!==void 0&&i.setAttribute("nonce",s),i.textContent=e.cssText,n.appendChild(i)}},X=Q?n=>n:n=>n instanceof CSSStyleSheet?(t=>{let e="";for(let i of t.cssRules)e+=i.cssText;return _t(e)})(n):n;var{is:Vt,defineProperty:Yt,getOwnPropertyDescriptor:Wt,getOwnPropertyNames:Ft,getOwnPropertySymbols:Zt,getPrototypeOf:Kt}=Object,tt=globalThis,wt=tt.trustedTypes,Gt=wt?wt.emptyScript:"",Jt=tt.reactiveElementPolyfillSupport,D=(n,t)=>n,z={toAttribute(n,t){switch(t){case Boolean:n=n?Gt:null;break;case Object:case Array:n=n==null?n:JSON.stringify(n)}return n},fromAttribute(n,t){let e=n;switch(t){case Boolean:e=n!==null;break;case Number:e=n===null?null:Number(n);break;case Object:case Array:try{e=JSON.parse(n)}catch{e=null}}return e}},et=(n,t)=>!Vt(n,t),At={attribute:!0,type:String,converter:z,reflect:!1,hasChanged:et};Symbol.metadata??=Symbol("metadata"),tt.litPropertyMetadata??=new WeakMap;var w=class extends HTMLElement{static addInitializer(t){this._$Ei(),(this.l??=[]).push(t)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(t,e=At){if(e.state&&(e.attribute=!1),this._$Ei(),this.elementProperties.set(t,e),!e.noAccessor){let i=Symbol(),s=this.getPropertyDescriptor(t,i,e);s!==void 0&&Yt(this.prototype,t,s)}}static getPropertyDescriptor(t,e,i){let{get:s,set:o}=Wt(this.prototype,t)??{get(){return this[e]},set(r){this[e]=r}};return{get(){return s?.call(this)},set(r){let c=s?.call(this);o.call(this,r),this.requestUpdate(t,c,i)},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)??At}static _$Ei(){if(this.hasOwnProperty(D("elementProperties")))return;let t=Kt(this);t.finalize(),t.l!==void 0&&(this.l=[...t.l]),this.elementProperties=new Map(t.elementProperties)}static finalize(){if(this.hasOwnProperty(D("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(D("properties"))){let e=this.properties,i=[...Ft(e),...Zt(e)];for(let s of i)this.createProperty(s,e[s])}let t=this[Symbol.metadata];if(t!==null){let e=litPropertyMetadata.get(t);if(e!==void 0)for(let[i,s]of e)this.elementProperties.set(i,s)}this._$Eh=new Map;for(let[e,i]of this.elementProperties){let s=this._$Eu(e,i);s!==void 0&&this._$Eh.set(s,e)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(t){let e=[];if(Array.isArray(t)){let i=new Set(t.flat(1/0).reverse());for(let s of i)e.unshift(X(s))}else t!==void 0&&e.push(X(t));return e}static _$Eu(t,e){let i=e.attribute;return i===!1?void 0:typeof i=="string"?i:typeof t=="string"?t.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(t=>this.enableUpdating=t),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(t=>t(this))}addController(t){(this._$EO??=new Set).add(t),this.renderRoot!==void 0&&this.isConnected&&t.hostConnected?.()}removeController(t){this._$EO?.delete(t)}_$E_(){let t=new Map,e=this.constructor.elementProperties;for(let i of e.keys())this.hasOwnProperty(i)&&(t.set(i,this[i]),delete this[i]);t.size>0&&(this._$Ep=t)}createRenderRoot(){let t=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return dt(t,this.constructor.elementStyles),t}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(t=>t.hostConnected?.())}enableUpdating(t){}disconnectedCallback(){this._$EO?.forEach(t=>t.hostDisconnected?.())}attributeChangedCallback(t,e,i){this._$AK(t,i)}_$EC(t,e){let i=this.constructor.elementProperties.get(t),s=this.constructor._$Eu(t,i);if(s!==void 0&&i.reflect===!0){let o=(i.converter?.toAttribute!==void 0?i.converter:z).toAttribute(e,i.type);this._$Em=t,o==null?this.removeAttribute(s):this.setAttribute(s,o),this._$Em=null}}_$AK(t,e){let i=this.constructor,s=i._$Eh.get(t);if(s!==void 0&&this._$Em!==s){let o=i.getPropertyOptions(s),r=typeof o.converter=="function"?{fromAttribute:o.converter}:o.converter?.fromAttribute!==void 0?o.converter:z;this._$Em=s,this[s]=r.fromAttribute(e,o.type),this._$Em=null}}requestUpdate(t,e,i){if(t!==void 0){if(i??=this.constructor.getPropertyOptions(t),!(i.hasChanged??et)(this[t],e))return;this.P(t,e,i)}this.isUpdatePending===!1&&(this._$ES=this._$ET())}P(t,e,i){this._$AL.has(t)||this._$AL.set(t,e),i.reflect===!0&&this._$Em!==t&&(this._$Ej??=new Set).add(t)}async _$ET(){this.isUpdatePending=!0;try{await this._$ES}catch(e){Promise.reject(e)}let t=this.scheduleUpdate();return t!=null&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(let[s,o]of this._$Ep)this[s]=o;this._$Ep=void 0}let i=this.constructor.elementProperties;if(i.size>0)for(let[s,o]of i)o.wrapped!==!0||this._$AL.has(s)||this[s]===void 0||this.P(s,this[s],o)}let t=!1,e=this._$AL;try{t=this.shouldUpdate(e),t?(this.willUpdate(e),this._$EO?.forEach(i=>i.hostUpdate?.()),this.update(e)):this._$EU()}catch(i){throw t=!1,this._$EU(),i}t&&this._$AE(e)}willUpdate(t){}_$AE(t){this._$EO?.forEach(e=>e.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t)}_$EU(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(t){return!0}update(t){this._$Ej&&=this._$Ej.forEach(e=>this._$EC(e,this[e])),this._$EU()}updated(t){}firstUpdated(t){}};w.elementStyles=[],w.shadowRootOptions={mode:"open"},w[D("elementProperties")]=new Map,w[D("finalized")]=new Map,Jt?.({ReactiveElement:w}),(tt.reactiveElementVersions??=[]).push("2.0.4");var mt=globalThis,it=mt.trustedTypes,Et=it?it.createPolicy("lit-html",{createHTML:n=>n}):void 0,ut="$lit$",A=`lit$${Math.random().toFixed(9).slice(2)}$`,ft="?"+A,Qt=`<${ft}>`,L=document,q=()=>L.createComment(""),V=n=>n===null||typeof n!="object"&&typeof n!="function",Mt=Array.isArray,Pt=n=>Mt(n)||typeof n?.[Symbol.iterator]=="function",pt=`[ 	
\f\r]`,j=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,Ct=/-->/g,xt=/>/g,S=RegExp(`>|${pt}(?:([^\\s"'>=/]+)(${pt}*=${pt}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),St=/'/g,Tt=/"/g,Rt=/^(?:script|style|textarea|title)$/i,Ht=n=>(t,...e)=>({_$litType$:n,strings:t,values:e}),h=Ht(1),me=Ht(2),M=Symbol.for("lit-noChange"),u=Symbol.for("lit-nothing"),Lt=new WeakMap,T=L.createTreeWalker(L,129);function Nt(n,t){if(!Array.isArray(n)||!n.hasOwnProperty("raw"))throw Error("invalid template strings array");return Et!==void 0?Et.createHTML(t):t}var Ut=(n,t)=>{let e=n.length-1,i=[],s,o=t===2?"<svg>":"",r=j;for(let c=0;c<e;c++){let a=n[c],m,f,p=-1,_=0;for(;_<a.length&&(r.lastIndex=_,f=r.exec(a),f!==null);)_=r.lastIndex,r===j?f[1]==="!--"?r=Ct:f[1]!==void 0?r=xt:f[2]!==void 0?(Rt.test(f[2])&&(s=RegExp("</"+f[2],"g")),r=S):f[3]!==void 0&&(r=S):r===S?f[0]===">"?(r=s??j,p=-1):f[1]===void 0?p=-2:(p=r.lastIndex-f[2].length,m=f[1],r=f[3]===void 0?S:f[3]==='"'?Tt:St):r===Tt||r===St?r=S:r===Ct||r===xt?r=j:(r=S,s=void 0);let C=r===S&&n[c+1].startsWith("/>")?" ":"";o+=r===j?a+Qt:p>=0?(i.push(m),a.slice(0,p)+ut+a.slice(p)+A+C):a+A+(p===-2?c:C)}return[Nt(n,o+(n[e]||"<?>")+(t===2?"</svg>":"")),i]},Y=class n{constructor({strings:t,_$litType$:e},i){let s;this.parts=[];let o=0,r=0,c=t.length-1,a=this.parts,[m,f]=Ut(t,e);if(this.el=n.createElement(m,i),T.currentNode=this.el.content,e===2){let p=this.el.content.firstChild;p.replaceWith(...p.childNodes)}for(;(s=T.nextNode())!==null&&a.length<c;){if(s.nodeType===1){if(s.hasAttributes())for(let p of s.getAttributeNames())if(p.endsWith(ut)){let _=f[r++],C=s.getAttribute(p).split(A),K=/([.?@])?(.*)/.exec(_);a.push({type:1,index:o,name:K[2],strings:C,ctor:K[1]==="."?nt:K[1]==="?"?ot:K[1]==="@"?rt:R}),s.removeAttribute(p)}else p.startsWith(A)&&(a.push({type:6,index:o}),s.removeAttribute(p));if(Rt.test(s.tagName)){let p=s.textContent.split(A),_=p.length-1;if(_>0){s.textContent=it?it.emptyScript:"";for(let C=0;C<_;C++)s.append(p[C],q()),T.nextNode(),a.push({type:2,index:++o});s.append(p[_],q())}}}else if(s.nodeType===8)if(s.data===ft)a.push({type:2,index:o});else{let p=-1;for(;(p=s.data.indexOf(A,p+1))!==-1;)a.push({type:7,index:o}),p+=A.length-1}o++}}static createElement(t,e){let i=L.createElement("template");return i.innerHTML=t,i}};function P(n,t,e=n,i){if(t===M)return t;let s=i!==void 0?e._$Co?.[i]:e._$Cl,o=V(t)?void 0:t._$litDirective$;return s?.constructor!==o&&(s?._$AO?.(!1),o===void 0?s=void 0:(s=new o(n),s._$AT(n,e,i)),i!==void 0?(e._$Co??=[])[i]=s:e._$Cl=s),s!==void 0&&(t=P(n,s._$AS(n,t.values),s,i)),t}var st=class{constructor(t,e){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=e}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){let{el:{content:e},parts:i}=this._$AD,s=(t?.creationScope??L).importNode(e,!0);T.currentNode=s;let o=T.nextNode(),r=0,c=0,a=i[0];for(;a!==void 0;){if(r===a.index){let m;a.type===2?m=new U(o,o.nextSibling,this,t):a.type===1?m=new a.ctor(o,a.name,a.strings,this,t):a.type===6&&(m=new at(o,this,t)),this._$AV.push(m),a=i[++c]}r!==a?.index&&(o=T.nextNode(),r++)}return T.currentNode=L,s}p(t){let e=0;for(let i of this._$AV)i!==void 0&&(i.strings!==void 0?(i._$AI(t,i,e),e+=i.strings.length-2):i._$AI(t[e])),e++}},U=class n{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(t,e,i,s){this.type=2,this._$AH=u,this._$AN=void 0,this._$AA=t,this._$AB=e,this._$AM=i,this.options=s,this._$Cv=s?.isConnected??!0}get parentNode(){let t=this._$AA.parentNode,e=this._$AM;return e!==void 0&&t?.nodeType===11&&(t=e.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,e=this){t=P(this,t,e),V(t)?t===u||t==null||t===""?(this._$AH!==u&&this._$AR(),this._$AH=u):t!==this._$AH&&t!==M&&this._(t):t._$litType$!==void 0?this.$(t):t.nodeType!==void 0?this.T(t):Pt(t)?this.k(t):this._(t)}S(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}T(t){this._$AH!==t&&(this._$AR(),this._$AH=this.S(t))}_(t){this._$AH!==u&&V(this._$AH)?this._$AA.nextSibling.data=t:this.T(L.createTextNode(t)),this._$AH=t}$(t){let{values:e,_$litType$:i}=t,s=typeof i=="number"?this._$AC(t):(i.el===void 0&&(i.el=Y.createElement(Nt(i.h,i.h[0]),this.options)),i);if(this._$AH?._$AD===s)this._$AH.p(e);else{let o=new st(s,this),r=o.u(this.options);o.p(e),this.T(r),this._$AH=o}}_$AC(t){let e=Lt.get(t.strings);return e===void 0&&Lt.set(t.strings,e=new Y(t)),e}k(t){Mt(this._$AH)||(this._$AH=[],this._$AR());let e=this._$AH,i,s=0;for(let o of t)s===e.length?e.push(i=new n(this.S(q()),this.S(q()),this,this.options)):i=e[s],i._$AI(o),s++;s<e.length&&(this._$AR(i&&i._$AB.nextSibling,s),e.length=s)}_$AR(t=this._$AA.nextSibling,e){for(this._$AP?.(!1,!0,e);t&&t!==this._$AB;){let i=t.nextSibling;t.remove(),t=i}}setConnected(t){this._$AM===void 0&&(this._$Cv=t,this._$AP?.(t))}},R=class{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(t,e,i,s,o){this.type=1,this._$AH=u,this._$AN=void 0,this.element=t,this.name=e,this._$AM=s,this.options=o,i.length>2||i[0]!==""||i[1]!==""?(this._$AH=Array(i.length-1).fill(new String),this.strings=i):this._$AH=u}_$AI(t,e=this,i,s){let o=this.strings,r=!1;if(o===void 0)t=P(this,t,e,0),r=!V(t)||t!==this._$AH&&t!==M,r&&(this._$AH=t);else{let c=t,a,m;for(t=o[0],a=0;a<o.length-1;a++)m=P(this,c[i+a],e,a),m===M&&(m=this._$AH[a]),r||=!V(m)||m!==this._$AH[a],m===u?t=u:t!==u&&(t+=(m??"")+o[a+1]),this._$AH[a]=m}r&&!s&&this.j(t)}j(t){t===u?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,t??"")}},nt=class extends R{constructor(){super(...arguments),this.type=3}j(t){this.element[this.name]=t===u?void 0:t}},ot=class extends R{constructor(){super(...arguments),this.type=4}j(t){this.element.toggleAttribute(this.name,!!t&&t!==u)}},rt=class extends R{constructor(t,e,i,s,o){super(t,e,i,s,o),this.type=5}_$AI(t,e=this){if((t=P(this,t,e,0)??u)===M)return;let i=this._$AH,s=t===u&&i!==u||t.capture!==i.capture||t.once!==i.once||t.passive!==i.passive,o=t!==u&&(i===u||s);s&&this.element.removeEventListener(this.name,this,i),o&&this.element.addEventListener(this.name,this,t),this._$AH=t}handleEvent(t){typeof this._$AH=="function"?this._$AH.call(this.options?.host??this.element,t):this._$AH.handleEvent(t)}},at=class{constructor(t,e,i){this.element=t,this.type=6,this._$AN=void 0,this._$AM=e,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(t){P(this,t)}},Ot={P:ut,A,C:ft,M:1,L:Ut,R:st,D:Pt,V:P,I:U,H:R,N:ot,U:rt,B:nt,F:at},Xt=mt.litHtmlPolyfillSupport;Xt?.(Y,U),(mt.litHtmlVersions??=[]).push("3.1.3");var kt=(n,t,e)=>{let i=e?.renderBefore??t,s=i._$litPart$;if(s===void 0){let o=e?.renderBefore??null;i._$litPart$=s=new U(t.insertBefore(q(),o),o,void 0,e??{})}return s._$AI(n),s};var d=class extends w{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){let t=super.createRenderRoot();return this.renderOptions.renderBefore??=t.firstChild,t}update(t){let e=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=kt(e,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return M}};d._$litElement$=!0,d.finalized=!0,globalThis.litElementHydrateSupport?.({LitElement:d});var te=globalThis.litElementPolyfillSupport;te?.({LitElement:d});(globalThis.litElementVersions??=[]).push("4.0.5");var b=n=>(t,e)=>{e!==void 0?e.addInitializer(()=>{customElements.define(n,t)}):customElements.define(n,t)};var{I:Me}=Ot;var It=n=>n.strings===void 0;var Bt={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},bt=n=>(...t)=>({_$litDirective$:n,values:t}),lt=class{constructor(t){}get _$AU(){return this._$AM._$AU}_$AT(t,e,i){this._$Ct=t,this._$AM=e,this._$Ci=i}_$AS(t,e){return this.update(t,e)}update(t,e){return this.render(...e)}};var W=(n,t)=>{let e=n._$AN;if(e===void 0)return!1;for(let i of e)i._$AO?.(t,!1),W(i,t);return!0},ht=n=>{let t,e;do{if((t=n._$AM)===void 0)break;e=t._$AN,e.delete(n),n=t}while(e?.size===0)},Dt=n=>{for(let t;t=n._$AM;n=t){let e=t._$AN;if(e===void 0)t._$AN=e=new Set;else if(e.has(n))break;e.add(n),se(t)}};function ee(n){this._$AN!==void 0?(ht(this),this._$AM=n,Dt(this)):this._$AM=n}function ie(n,t=!1,e=0){let i=this._$AH,s=this._$AN;if(s!==void 0&&s.size!==0)if(t)if(Array.isArray(i))for(let o=e;o<i.length;o++)W(i[o],!1),ht(i[o]);else i!=null&&(W(i,!1),ht(i));else W(this,n)}var se=n=>{n.type==Bt.CHILD&&(n._$AP??=ie,n._$AQ??=ee)},ct=class extends lt{constructor(){super(...arguments),this._$AN=void 0}_$AT(t,e,i){super._$AT(t,e,i),Dt(this),this.isConnected=t._$AU}_$AO(t,e=!0){t!==this.isConnected&&(this.isConnected=t,t?this.reconnected?.():this.disconnected?.()),e&&(W(this,t),ht(this))}setValue(t){if(It(this._$Ct))this._$Ct._$AI(t,this);else{let e=[...this._$Ct._$AH];e[this._$Ci]=t,this._$Ct._$AI(e,this,0)}}disconnected(){}reconnected(){}};var y=()=>new gt,gt=class{},$t=new WeakMap,g=bt(class extends ct{render(n){return u}update(n,[t]){let e=t!==this.Y;return e&&this.Y!==void 0&&this.rt(void 0),(e||this.lt!==this.ct)&&(this.Y=t,this.ht=n.options?.host,this.rt(this.ct=n.element)),u}rt(n){if(typeof this.Y=="function"){let t=this.ht??globalThis,e=$t.get(t);e===void 0&&(e=new WeakMap,$t.set(t,e)),e.get(this.Y)!==void 0&&this.Y.call(this.ht,void 0),e.set(this.Y,n),n!==void 0&&this.Y.call(this.ht,n)}else this.Y.value=n}get lt(){return typeof this.Y=="function"?$t.get(this.ht??globalThis)?.get(this.Y):this.Y?.value}disconnected(){this.lt===this.ct&&this.rt(void 0)}reconnected(){this.rt(this.ct)}});var ne={attribute:!0,type:String,converter:z,reflect:!1,hasChanged:et},oe=(n=ne,t,e)=>{let{kind:i,metadata:s}=e,o=globalThis.litPropertyMetadata.get(s);if(o===void 0&&globalThis.litPropertyMetadata.set(s,o=new Map),o.set(e.name,n),i==="accessor"){let{name:r}=e;return{set(c){let a=t.get.call(this);t.set.call(this,c),this.requestUpdate(r,a,n)},init(c){return c!==void 0&&this.P(r,void 0,n),c}}}if(i==="setter"){let{name:r}=e;return function(c){let a=this[r];t.call(this,c),this.requestUpdate(r,a,n)}}throw Error("Unsupported decorator location: "+i)};function $(n){return(t,e)=>typeof e=="object"?oe(n,t,e):((i,s,o)=>{let r=s.hasOwnProperty(o);return s.constructor.createProperty(o,r?{...i,wrapped:!0}:i),r?Object.getOwnPropertyDescriptor(s,o):void 0})(n,t,e)}function v(n){return $({...n,state:!0,attribute:!1})}var H=class extends d{constructor(){super(...arguments);this.createRenderRoot=()=>this}connectedCallback(){super.connectedCallback(),this.addEventListener("contextmenu",e=>{e.preventDefault(),window.actionSheetController.create({header:this.file.name,buttons:[{text:"Abrir",handler:this.launch.bind(this)},{text:"Copiar",handler:()=>this.dispatchEvent(new CustomEvent("copy",{detail:[...this.path,this.file.name]}))},{text:"Cortar",handler:()=>this.dispatchEvent(new CustomEvent("cut",{detail:[...this.path,this.file.name]}))},{text:"Renombrar",handler:()=>this.dispatchEvent(new CustomEvent("rename",{detail:[...this.path,this.file.name]}))},{text:"Descargar",handler:this.download.bind(this)},{text:"Compartir",handler:this.share.bind(this)},{text:"Mover a la papelera",role:"destructive",handler:this.delete.bind(this)},{text:"Cancelar",role:"cancel"}]}).then(i=>i.present())})}formatSize(e){if(e===0)return"0 Bytes";let i=1024,s=["Bytes","KB","MB","GB","TB","PB","EB","ZB","YB"],o=Math.floor(Math.log(e)/Math.log(i));return parseFloat((e/Math.pow(i,o)).toFixed(2))+" "+s[o]}launch(){let e=[...this.path,this.file.name],i=e.shift();window.launchFile(i,...e)}async download(){document.querySelector("page-swaps")?.addItem([...this.path,this.file.name])}async delete(){let e=await window.loadingController.create({message:"Eliminando archivo ..."});await e.present(),await document.querySelector("page-recycle-bin")?.add([...this.path,this.file.name]),await e.dismiss(),this.remove(),this.dispatchEvent(new CustomEvent("delete"))}async share(){let e=[...this.path,this.file.name];document.querySelector("page-shared")?.addItem(e)}render(){return h`
      <ion-item button @click=${this.launch.bind(this)}>
        <ion-icon slot="start" name="document-outline"></ion-icon>
        <ion-label>
          ${this.file.name}
          <p>${this.formatSize(this.file.size)}</p>
        </ion-label>
      </ion-item>
    `}};l([$({type:Array})],H.prototype,"path",2),l([$({type:Object})],H.prototype,"file",2),H=l([b("file-item")],H);var N=class extends d{constructor(){super(...arguments);this.createRenderRoot=()=>this}connectedCallback(){super.connectedCallback(),this.addEventListener("contextmenu",e=>{e.preventDefault(),window.actionSheetController.create({header:this.folder.name,buttons:[{text:"Abrir",handler:this.launch.bind(this)},{text:"Copiar",handler:()=>this.dispatchEvent(new CustomEvent("copy",{detail:[...this.path,this.folder.name]}))},{text:"Cortar",handler:()=>this.dispatchEvent(new CustomEvent("cut",{detail:[...this.path,this.folder.name]}))},{text:"Renombrar",handler:()=>this.dispatchEvent(new CustomEvent("rename",{detail:[...this.path,this.folder.name]}))},{text:"Mover a la papelera",role:"destructive",handler:this.delete.bind(this)},{text:"Cancelar",role:"cancel"}]}).then(i=>i.present())})}launch(){this.dispatchEvent(new CustomEvent("go",{detail:[...this.path,this.folder.name]}))}async delete(){let e=await window.loadingController.create({message:"Eliminando carpeta ..."});await e.present(),await document.querySelector("page-recycle-bin")?.add([...this.path,this.folder.name]),await e.dismiss(),this.remove(),this.dispatchEvent(new CustomEvent("delete"))}render(){return h`
      <ion-item button @click=${this.launch.bind(this)}>
        <ion-icon slot="start" name="folder-outline"></ion-icon>
        <ion-label>${this.folder.name}</ion-label>
      </ion-item>
    `}};l([$({type:Array})],N.prototype,"path",2),l([$({type:Object})],N.prototype,"folder",2),N=l([b("folder-item")],N);var zt={shared:"Carpeta compartida",user:"Carpeta personal"},x=class extends d{constructor(){super(...arguments);this.path=[];this.folders=[];this.files=[];this.breadcrumbs=y();this.createRenderRoot=()=>this}async go(e){this.config||(this.config=await window.connectors.storage.user.get("fs")||{showHidden:!1});let{showHidden:i}=this.config;if(this.path=e,this.folders=[],this.files=[],e.length>0){let s=[...e],o=s.shift(),r=await window.loadingController.create({message:"Cargando contenido ..."});await r.present();let c;o==="shared"?c=await window.connectors.fs.sharedLs(s,{showHidden:i}):c=await window.connectors.fs.userLs(s,{showHidden:i}),Array.isArray(c)||(c=[]),c=c.sort();let a=[],m=[];for(let f of c)f.isFile?m.push(f):a.push(f);this.folders=a,this.files=m,await r.dismiss()}}createFolder(){let e=this.go.bind(this),i=[...this.path],s=i.shift();window.alertController.create({header:"Crear carpeta",message:"Escribe el nombre de la nueva carpeta",inputs:[{name:"name",type:"text"}],buttons:[{role:"cancel",text:"Cancelar"},{role:"destructive",text:"Crear",async handler({name:o}){if(!/^[a-zA-Z0-9_ ]+(?:\.[a-zA-Z0-9_ ]+)*$/.test(o))window.alertController.create({header:"Nombre inv\xE1lido",message:"El nombre que indicaste no es v\xE1lido.",buttons:["Aceptar"]}).then(r=>r.present());else{let r=await window.loadingController.create({message:"Creando carpeta ..."});await r.present();let c=[...i,o];s==="shared"?await window.connectors.fs.sharedMkdir(c):await window.connectors.fs.userMkdir(c),await r.dismiss(),e([s,...i])}}}]}).then(o=>o.present())}selectFile(){let{path:e}=this,i=document.createElement("input");i.type="file",i.multiple=!0,i.addEventListener("change",()=>{if(i.files)for(let s=0;s<i.files.length;s++){let o=i.files.item(s);o&&document.querySelector("page-swaps")?.addItem([...e],o)}}),i.click()}updated(e){super.updated(e),setTimeout(()=>{let{value:i}=this.breadcrumbs;i&&(i.scrollLeft=i.scrollWidth-i.clientWidth)},100)}async paste(){let e=await window.loadingController.create({});this.clipboardCopy&&(e.message="Copiando ...",await e.present(),await window.connectors.fs.copy(this.clipboardCopy,this.path),this.clipboardCopy=void 0),this.clipboardCut&&(e.message="Moviendo ...",await e.present(),await window.connectors.fs.copy(this.clipboardCut,this.path),this.clipboardCut=void 0),await e.dismiss(),this.go(this.path)}rename(e,i=!1){let s=o=>{i&&(this.path.pop(),this.path.push(o)),this.go(this.path)};window.alertController.create({header:"Renombrar",message:"Escribe el nuevo nombre",inputs:[{type:"text",name:"nName",value:e[e.length-1]}],buttons:[{text:"Cancelar",role:"cancel"},{text:"Renombrar",async handler({nName:o}){let r=o.trim();if(r)if(!/^[a-zA-Z0-9_ ]+(?:\.[a-zA-Z0-9_ ]+)*$/.test(r))window.alertController.create({header:"Nombre inv\xE1lido",message:"El nombre que indicaste no es v\xE1lido.",buttons:["Aceptar"]}).then(c=>c.present());else{let c=await window.loadingController.create({message:"Renombrando ..."});await c.present(),await window.connectors.fs.rename(e,r),await c.dismiss(),s(r)}}}]}).then(o=>o.present())}async toggleShowHidden(){this.config.showHidden=!this.config.showHidden,await window.connectors.storage.user.set("fs",this.config),this.go(this.path)}async handlerOptions(){let{showHidden:e}=this.config,i=this.rename.bind(this),s=[{text:"Actualizar",handler:()=>this.go(this.path)},{text:"Crear carpeta",handler:this.createFolder.bind(this)},{text:"Subir archivo",handler:this.selectFile.bind(this)},{text:e?"No mostrar archivos ocultos":"Mostrar archivos ocultos",handler:this.toggleShowHidden.bind(this)}];this.path.length>1&&s.push({text:"Renombrar",handler:()=>i([...this.path],!0)}),(this.clipboardCopy||this.clipboardCut)&&s.push({text:"Pegar",handler:this.paste.bind(this)}),s.push({text:"Cancelar",role:"cancel"});let o=this.path[this.path.length-1];await(await window.actionSheetController.create({header:zt[o]||o,buttons:s})).present()}render(){return h`
      <ion-header>
        <ion-toolbar>
          <ion-title>Archivos</ion-title>
          ${this.path.length===0?"":h`
            <ion-buttons slot="end">
              <ion-button button @click=${this.handlerOptions.bind(this)}>
                <ion-icon slot="icon-only" name="options"></ion-icon>
              </ion-button>
            </ion-buttons>
          `}
        </ion-toolbar>
      </ion-header>
      <ion-content>
        <style>
          ion-list {
            position: fixed;
            max-height: calc(100% - 165px);
            width: calc(100% - 32px);
            overflow-y: auto !important;
          }
          .breadcrumbs {
            display: contents;
          }
          ion-breadcrumbs {
            overflow: auto;
            flex-wrap: nowrap;
            scroll-behavior: smooth;
          }
          ion-breadcrumb {
            cursor: pointer;
          }
          folder-item {
            position: relative;
          }
        </style>
        ${this.path.length===0?"":h`
          <div class="breadcrumbs">
            <ion-card>
              <ion-card-content>
                <ion-breadcrumbs ${g(this.breadcrumbs)}>
                  <ion-breadcrumb @click=${()=>this.go([])}>Inicio</ion-breadcrumb>
                  ${this.path.map((e,i,s)=>h`
                    <ion-breadcrumb @click=${()=>this.go(s.slice(0,i+1))}>
                      ${zt[e]||e}
                    </ion-breadcrumb>
                  `)}
                </ion-breadcrumbs>
              </ion-card-content>
            </ion-card>
          </div>
        `}
        <ion-list inset>
          ${this.path.length>0?h`
            ${this.folders.map(e=>h`
              <folder-item
                .path=${this.path}
                .folder=${e}
                @go=${({detail:i})=>this.go(i)}
                @copy=${({detail:i})=>this.clipboardCopy=i}
                @cut=${({detail:i})=>this.clipboardCut=i}
                @delete=${()=>this.go(this.path)}
                @rename=${({detail:i})=>this.rename(i)}
              ></folder-item>
            `)}
            ${this.files.map(e=>h`
              <file-item
                .path=${this.path}
                .file=${e}
                @copy=${({detail:i})=>this.clipboardCopy=i}
                @cut=${({detail:i})=>this.clipboardCut=i}
                @delete=${()=>this.go(this.path)}
                @rename=${({detail:i})=>this.rename(i)}
              ></file-item>
            `)}
            ${this.folders.length===0&&this.files.length===0?h`
              <ion-item>
                <ion-label class="ion-text-center">No hay elementos.</ion-label>
              </ion-item>
            `:""}
          `:h`
            <ion-item button @click=${()=>this.go(["shared"])}>
              <ion-icon slot="start" name="share-outline"></ion-icon>
              <ion-label>Carpeta compartida</ion-label>
            </ion-item>
            <ion-item button @click=${()=>this.go(["user"])}>
              <ion-icon slot="start" name="home-outline"></ion-icon>
              <ion-label>Carpeta personal</ion-label>
            </ion-item>
          `}
        </ion-list>
      </ion-content>
    `}};l([v()],x.prototype,"path",2),l([v()],x.prototype,"folders",2),l([v()],x.prototype,"files",2),x=l([b("page-files")],x);var F=class extends d{constructor(){super();this.createRenderRoot=()=>this;this.addEventListener("click",()=>{this.item&&window.alertController.create({header:this.item.path[this.item.path.length-1],message:`Fecha de eliminaci\xF3n: ${this.item.date}
Ruta: ${this.item.path.join("/")}`,cssClass:["rb-alert"],buttons:["Aceptar"]}).then(e=>e.present())}),this.addEventListener("contextmenu",e=>{e.preventDefault(),this.item&&window.actionSheetController.create({header:this.item.path[this.item.path.length-1],buttons:[{text:"Restaurar",handler:this.restore.bind(this)},{text:"Eliminar",role:"destructive",handler:this.delete.bind(this)},{text:"Cancelar",role:"cancel"}]}).then(i=>i.present())})}async restore(e){let i=this.item?.id||"";this.item=void 0,await window.connectors.recycleBin.restore(i),e||this.dispatchEvent(new CustomEvent("remove"))}async delete(e){let i=this.item?.id||"";this.item=void 0,await window.connectors.recycleBin.delete(i),e||this.dispatchEvent(new CustomEvent("remove"))}render(){return this.item?h`
        <ion-item button>
          <ion-label>
            ${this.item.path[this.item.path.length-1]}
            <p>${this.item.date}</p>
          </ion-label>
        </ion-item>
      `:h`
        <ion-item>
          <ion-progress-bar type="indeterminate"></ion-progress-bar>
        </ion-item>
      `}};l([$({type:Object})],F.prototype,"item",2),F=l([b("recycle-bin-item")],F);var re={shared:"Carpeta compartida",user:"Carpeta personal"},O=class extends d{constructor(){super();this.itemsList=[];this.loading=!0;this.createRenderRoot=()=>this;this.loadItems()}async add(e){await window.connectors.recycleBin.add(e),await this.loadItems()}async loadItems(){this.loading=!0,this.itemsList=(await window.connectors.recycleBin.list()).map(i=>(i.path[0]=re[i.path[0]]||i.path[0],i));let e=document.querySelector('ion-tab-button[tab="recycle-bin"] ion-icon');this.itemsList.length>0?e.name="file-tray-full-outline":e.name="file-tray-outline",this.loading=!1}async clean(){this.loading=!0;let e=this.querySelectorAll("recycle-bin-item");for(let i=0;i<e.length;i++)await e.item(i).delete(!0);this.loading=!1,this.itemsList=[]}render(){return h`
      <style>
        .rb-alert .alert-message {
          text-wrap: balance;
        }
      </style>
      <ion-header>
        <ion-toolbar>
          <ion-title>Papelera de reciclaje</ion-title>
          ${this.itemsList.length===0?"":h`
            <ion-buttons slot="end">
              <ion-button button @click=${this.clean.bind(this)}>
                <ion-icon slot="icon-only" name="trash-bin-outline"></ion-icon>
              </ion-button>
            </ion-buttons>
          `}
        </ion-toolbar>
        ${this.loading?h`<ion-progress-bar type="indeterminate"></ion-progress-bar>`:""}
      </ion-header>
      <ion-content>
        <ion-list inset>
          ${this.itemsList.length>0?"":h`
            <ion-item>
              <ion-label class="ion-text-center">No hay archivos.</ion-label>
            </ion-item>
          `}
          ${this.itemsList.map(e=>h`
            <recycle-bin-item
              .item=${e}
              @remove=${this.loadItems.bind(this)}
            ></recycle-bin-item>
          `)}
        </ion-list>
      </ion-content>
    `}};l([v()],O.prototype,"itemsList",2),l([v()],O.prototype,"loading",2),O=l([b("page-recycle-bin")],O);var E=class extends d{constructor(){super(...arguments);this.status="Preparando ...";this.path=[];this.finished=!0;this.createRenderRoot=()=>this}connectedCallback(){if(super.connectedCallback(),this.file){let e=[...this.path];e.shift()==="shared"?this.fileTransfer=window.connectors.fs.sharedUpload({path:e,file:this.file}):this.fileTransfer=window.connectors.fs.userUpload({path:e,file:this.file})}else this.fileTransfer=window.createDownloader(this.path);this.fileTransfer.on("end",()=>{this.status="Completado.",this.finished=!0}),this.fileTransfer.on("error",()=>{this.status=`Ocurri\xF3 un error al intentar ${this.file?"subir":"descargar"} el archivo.`,this.finished=!0}),this.fileTransfer.on("abort",()=>{this.status=`La ${this.file?"subida":"descarga"} fue cancelada.`,this.finished=!0}),this.fileTransfer.on("progress",e=>{this.status=`${e.toString()}%`}),this.fileTransfer.start(),this.finished=!1}end(){this.finished?(this.dispatchEvent(new CustomEvent("remove")),this.remove()):this.fileTransfer.cancel()}render(){return h`
      <ion-item>
        <ion-icon slot="start" name="cloud-${this.file?"upload":"download"}-outline"></ion-icon>
        <ion-label>
          ${this.file?this.file.name:this.path[this.path.length-1]}
          <p>${this.status}</p>
        </ion-label>
        <ion-button slot="end" fill="clear" @click=${this.end.bind(this)}>
          <ion-icon slot="icon-only" name="close"></ion-icon>
        </ion-button>
      </ion-item>
    `}};l([v()],E.prototype,"status",2),l([$({type:Array})],E.prototype,"path",2),l([$({type:File})],E.prototype,"file",2),l([$({type:Boolean})],E.prototype,"finished",2),E=l([b("swap-item")],E);var k=class extends d{constructor(){super(...arguments);this.counter=0;this.listRef=y();this.createRenderRoot=()=>this}addItem(e,i){setTimeout(()=>document.querySelector("ion-tabs").select("swap"),500),setTimeout(()=>{let s=document.createElement("swap-item");s.path=e,i&&(s.file=i),s.addEventListener("remove",()=>this.counter--),this.listRef.value?.append(s),this.counter++},750)}clean(){let e=0;this.querySelectorAll("swap-item").forEach(i=>{i.finished&&(e++,i.remove())}),this.counter-=e}render(){return h`
      <ion-header>
        <ion-toolbar>
          <ion-title>Transferencias</ion-title>
          ${this.counter===0?"":h`
            <ion-buttons slot="end">
              <ion-buttons slot="end">
                <ion-button button @click=${this.clean.bind(this)}>
                  <ion-icon slot="icon-only" name="trash-bin-outline"></ion-icon>
                </ion-button>
              </ion-buttons>
            </ion-buttons>
          `}
        </ion-toolbar>
      </ion-header>
      <ion-content>
        <ion-list ${g(this.listRef)} inset>
          ${this.counter>0?"":h`
            <ion-item>
              <ion-label class="ion-text-center">No hay Transferencias.</ion-label>
            </ion-item>
          `}
        </ion-list>
      </ion-content>
    `}};l([v()],k.prototype,"counter",2),k=l([b("page-swaps")],k);var I=class extends d{constructor(){super(...arguments);this.slidingElement=y();this.createRenderRoot=()=>this}connectedCallback(){super.connectedCallback(),this.addEventListener("contextmenu",e=>{e.preventDefault(),this.slidingElement.value?.open("end")})}async copy(){if(await this.slidingElement.value?.close(),"clipboard"in navigator){let i=window.createURL({path:["shared",this.shared.id]}).href;document.hasFocus()&&navigator.clipboard.writeText(i)}await(await window.toastController.create({message:"Copiado!",buttons:["Aceptar"],duration:1500})).present()}async delete(){await this.slidingElement.value?.close();let e=await window.loadingController.create({message:"Eliminando ..."});await e.present(),await window.connectors.shared.delete(this.shared.id),await e.dismiss(),this.dispatchEvent(new CustomEvent("delete"))}render(){return h`
      <ion-item-sliding ${g(this.slidingElement)}>
        <ion-item>
          <ion-icon slot="start" name="share-social-outline"></ion-icon>
          <ion-label>${this.shared.path[this.shared.path.length-1]}</ion-label>
        </ion-item>
        <ion-item-options slot="end">
          <ion-item-option @click=${this.copy.bind(this)}>
            <ion-icon slot="icon-only" name="clipboard-outline"></ion-icon>
          </ion-item-option>
          <ion-item-option color="danger" @click=${this.delete.bind(this)}>
            <ion-icon slot="icon-only" name="trash-outline"></ion-icon>
          </ion-item-option>
        </ion-item-options>
      </ion-item-sliding>
    `}};l([$({type:Object})],I.prototype,"shared",2),I=l([b("shared-item")],I);var B=class extends d{constructor(){super();this.sharedList=[];this.createRenderRoot=()=>this;this.loadItems()}async addItem(e){let i=await window.toastController.create({message:"Compartiendo ...",buttons:["Aceptar"]});await i.present();let s=await window.connectors.shared.create(e);if(i.message="Compartido!",i.duration=1500,i.isOpen||await i.present(),"clipboard"in navigator){let o=window.createURL({path:["shared",s.id]}).href;document.hasFocus()&&navigator.clipboard.writeText(o)}this.loadItems()}async loadItems(){this.sharedList=await window.connectors.shared.list()}render(){return h`
      <ion-header>
        <ion-toolbar>
          <ion-title>Archivos compartidos</ion-title>
        </ion-toolbar>
      </ion-header>
      <ion-content>
        <ion-list inset>
          ${this.sharedList.length>0?"":h`
            <ion-item>
              <ion-label class="ion-text-center">No hay archivos compartidos.</ion-label>
            </ion-item>
          `}
          ${this.sharedList.map(e=>h`<shared-item .shared=${e} @delete=${this.loadItems.bind(this)}></shared-item>`)}
        </ion-list>
      </ion-content>
    `}};l([v()],B.prototype,"sharedList",2),B=l([b("page-shared")],B);var Z=class extends d{constructor(){super(...arguments);this.filesPage=y();this.swapPage=y();this.sharedPage=y();this.recycleBinPage=y();this.createRenderRoot=()=>this}render(){return h`
      <ion-tabs>
        <ion-tab tab="files">
          <page-files ${g(this.filesPage)}></page-files>
          <ion-nav ${g(e=>e.root=this.filesPage.value)}></ion-nav>
        </ion-tab>
        <ion-tab tab="swap">
          <page-swaps ${g(this.swapPage)}></page-swaps>
          <ion-nav ${g(e=>e.root=this.swapPage.value)}></ion-nav>
        </ion-tab>
        <ion-tab tab="shared">
          <page-shared ${g(this.sharedPage)}></page-shared>
          <ion-nav ${g(e=>e.root=this.sharedPage.value)}></ion-nav>
        </ion-tab>
        <ion-tab tab="recycle-bin">
          <page-recycle-bin ${g(this.recycleBinPage)}></page-recycle-bin>
          <ion-nav ${g(e=>e.root=this.recycleBinPage.value)}></ion-nav>
        </ion-tab>
        <ion-tab-bar slot="bottom">
          <ion-tab-button tab="files">
            <ion-icon name="home-outline"></ion-icon>
          </ion-tab-button>
          <ion-tab-button tab="swap">
            <ion-icon name="swap-vertical-outline"></ion-icon>
          </ion-tab-button>
          <ion-tab-button tab="shared">
            <ion-icon name="share-outline"></ion-icon>
          </ion-tab-button>
          <ion-tab-button tab="recycle-bin">
            <ion-icon name="file-tray-outline"></ion-icon>
          </ion-tab-button>
        </ion-tab-bar>
      </ion-tabs>
    `}};Z=l([b("app-root")],Z);document.addEventListener("onReady",()=>document.body.innerHTML="<app-root></app-root>");export{Z as default};
/*! Bundled license information:

@lit/reactive-element/css-tag.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/reactive-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/lit-html.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-element/lit-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/is-server.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/custom-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/directive-helpers.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/directive.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/async-directive.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/directives/ref.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/property.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/state.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
