var ke=Object.defineProperty;var De=Object.getOwnPropertyDescriptor;var $=(i,e,t,s)=>{for(var o=s>1?void 0:s?De(e,t):e,n=i.length-1,r;n>=0;n--)(r=i[n])&&(o=(s?r(e,t,o):r(o))||o);return s&&o&&ke(e,t,o),o};var W=globalThis,F=W.ShadowRoot&&(W.ShadyCSS===void 0||W.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,ae=Symbol(),$e=new WeakMap,O=class{constructor(e,t,s){if(this._$cssResult$=!0,s!==ae)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o,t=this.t;if(F&&e===void 0){let s=t!==void 0&&t.length===1;s&&(e=$e.get(t)),e===void 0&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),s&&$e.set(t,e))}return e}toString(){return this.cssText}},ve=i=>new O(typeof i=="string"?i:i+"",void 0,ae),E=(i,...e)=>{let t=i.length===1?i[0]:e.reduce((s,o,n)=>s+(r=>{if(r._$cssResult$===!0)return r.cssText;if(typeof r=="number")return r;throw Error("Value passed to 'css' function must be a 'css' function result: "+r+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(o)+i[n+1],i[0]);return new O(t,i,ae)},le=(i,e)=>{if(F)i.adoptedStyleSheets=e.map(t=>t instanceof CSSStyleSheet?t:t.styleSheet);else for(let t of e){let s=document.createElement("style"),o=W.litNonce;o!==void 0&&s.setAttribute("nonce",o),s.textContent=t.cssText,i.appendChild(s)}},K=F?i=>i:i=>i instanceof CSSStyleSheet?(e=>{let t="";for(let s of e.cssRules)t+=s.cssText;return ve(t)})(i):i;var{is:Be,defineProperty:je,getOwnPropertyDescriptor:ze,getOwnPropertyNames:qe,getOwnPropertySymbols:Ve,getPrototypeOf:Ye}=Object,G=globalThis,ge=G.trustedTypes,We=ge?ge.emptyScript:"",Fe=G.reactiveElementPolyfillSupport,k=(i,e)=>i,D={toAttribute(i,e){switch(e){case Boolean:i=i?We:null;break;case Object:case Array:i=i==null?i:JSON.stringify(i)}return i},fromAttribute(i,e){let t=i;switch(e){case Boolean:t=i!==null;break;case Number:t=i===null?null:Number(i);break;case Object:case Array:try{t=JSON.parse(i)}catch{t=null}}return t}},Q=(i,e)=>!Be(i,e),_e={attribute:!0,type:String,converter:D,reflect:!1,hasChanged:Q};Symbol.metadata??=Symbol("metadata"),G.litPropertyMetadata??=new WeakMap;var A=class extends HTMLElement{static addInitializer(e){this._$Ei(),(this.l??=[]).push(e)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(e,t=_e){if(t.state&&(t.attribute=!1),this._$Ei(),this.elementProperties.set(e,t),!t.noAccessor){let s=Symbol(),o=this.getPropertyDescriptor(e,s,t);o!==void 0&&je(this.prototype,e,o)}}static getPropertyDescriptor(e,t,s){let{get:o,set:n}=ze(this.prototype,e)??{get(){return this[t]},set(r){this[t]=r}};return{get(){return o?.call(this)},set(r){let l=o?.call(this);n.call(this,r),this.requestUpdate(e,l,s)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)??_e}static _$Ei(){if(this.hasOwnProperty(k("elementProperties")))return;let e=Ye(this);e.finalize(),e.l!==void 0&&(this.l=[...e.l]),this.elementProperties=new Map(e.elementProperties)}static finalize(){if(this.hasOwnProperty(k("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(k("properties"))){let t=this.properties,s=[...qe(t),...Ve(t)];for(let o of s)this.createProperty(o,t[o])}let e=this[Symbol.metadata];if(e!==null){let t=litPropertyMetadata.get(e);if(t!==void 0)for(let[s,o]of t)this.elementProperties.set(s,o)}this._$Eh=new Map;for(let[t,s]of this.elementProperties){let o=this._$Eu(t,s);o!==void 0&&this._$Eh.set(o,t)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(e){let t=[];if(Array.isArray(e)){let s=new Set(e.flat(1/0).reverse());for(let o of s)t.unshift(K(o))}else e!==void 0&&t.push(K(e));return t}static _$Eu(e,t){let s=t.attribute;return s===!1?void 0:typeof s=="string"?s:typeof e=="string"?e.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(e=>this.enableUpdating=e),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(e=>e(this))}addController(e){(this._$EO??=new Set).add(e),this.renderRoot!==void 0&&this.isConnected&&e.hostConnected?.()}removeController(e){this._$EO?.delete(e)}_$E_(){let e=new Map,t=this.constructor.elementProperties;for(let s of t.keys())this.hasOwnProperty(s)&&(e.set(s,this[s]),delete this[s]);e.size>0&&(this._$Ep=e)}createRenderRoot(){let e=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return le(e,this.constructor.elementStyles),e}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(e=>e.hostConnected?.())}enableUpdating(e){}disconnectedCallback(){this._$EO?.forEach(e=>e.hostDisconnected?.())}attributeChangedCallback(e,t,s){this._$AK(e,s)}_$EC(e,t){let s=this.constructor.elementProperties.get(e),o=this.constructor._$Eu(e,s);if(o!==void 0&&s.reflect===!0){let n=(s.converter?.toAttribute!==void 0?s.converter:D).toAttribute(t,s.type);this._$Em=e,n==null?this.removeAttribute(o):this.setAttribute(o,n),this._$Em=null}}_$AK(e,t){let s=this.constructor,o=s._$Eh.get(e);if(o!==void 0&&this._$Em!==o){let n=s.getPropertyOptions(o),r=typeof n.converter=="function"?{fromAttribute:n.converter}:n.converter?.fromAttribute!==void 0?n.converter:D;this._$Em=o,this[o]=r.fromAttribute(t,n.type),this._$Em=null}}requestUpdate(e,t,s){if(e!==void 0){if(s??=this.constructor.getPropertyOptions(e),!(s.hasChanged??Q)(this[e],t))return;this.P(e,t,s)}this.isUpdatePending===!1&&(this._$ES=this._$ET())}P(e,t,s){this._$AL.has(e)||this._$AL.set(e,t),s.reflect===!0&&this._$Em!==e&&(this._$Ej??=new Set).add(e)}async _$ET(){this.isUpdatePending=!0;try{await this._$ES}catch(t){Promise.reject(t)}let e=this.scheduleUpdate();return e!=null&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(let[o,n]of this._$Ep)this[o]=n;this._$Ep=void 0}let s=this.constructor.elementProperties;if(s.size>0)for(let[o,n]of s)n.wrapped!==!0||this._$AL.has(o)||this[o]===void 0||this.P(o,this[o],n)}let e=!1,t=this._$AL;try{e=this.shouldUpdate(t),e?(this.willUpdate(t),this._$EO?.forEach(s=>s.hostUpdate?.()),this.update(t)):this._$EU()}catch(s){throw e=!1,this._$EU(),s}e&&this._$AE(t)}willUpdate(e){}_$AE(e){this._$EO?.forEach(t=>t.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$EU(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(e){return!0}update(e){this._$Ej&&=this._$Ej.forEach(t=>this._$EC(t,this[t])),this._$EU()}updated(e){}firstUpdated(e){}};A.elementStyles=[],A.shadowRootOptions={mode:"open"},A[k("elementProperties")]=new Map,A[k("finalized")]=new Map,Fe?.({ReactiveElement:A}),(G.reactiveElementVersions??=[]).push("2.0.4");var he=globalThis,Z=he.trustedTypes,Ae=Z?Z.createPolicy("lit-html",{createHTML:i=>i}):void 0,de="$lit$",y=`lit$${Math.random().toFixed(9).slice(2)}$`,ue="?"+y,Ke=`<${ue}>`,x=document,j=()=>x.createComment(""),z=i=>i===null||typeof i!="object"&&typeof i!="function",xe=Array.isArray,Ce=i=>xe(i)||typeof i?.[Symbol.iterator]=="function",ce=`[ 	
\f\r]`,B=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,ye=/-->/g,be=/>/g,w=RegExp(`>|${ce}(?:([^\\s"'>=/]+)(${ce}*=${ce}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),Ee=/'/g,we=/"/g,Te=/^(?:script|style|textarea|title)$/i,Re=i=>(e,...t)=>({_$litType$:i,strings:e,values:t}),v=Re(1),at=Re(2),C=Symbol.for("lit-noChange"),d=Symbol.for("lit-nothing"),Se=new WeakMap,S=x.createTreeWalker(x,129);function Le(i,e){if(!Array.isArray(i)||!i.hasOwnProperty("raw"))throw Error("invalid template strings array");return Ae!==void 0?Ae.createHTML(e):e}var Ue=(i,e)=>{let t=i.length-1,s=[],o,n=e===2?"<svg>":"",r=B;for(let l=0;l<t;l++){let a=i[l],h,m,c=-1,_=0;for(;_<a.length&&(r.lastIndex=_,m=r.exec(a),m!==null);)_=r.lastIndex,r===B?m[1]==="!--"?r=ye:m[1]!==void 0?r=be:m[2]!==void 0?(Te.test(m[2])&&(o=RegExp("</"+m[2],"g")),r=w):m[3]!==void 0&&(r=w):r===w?m[0]===">"?(r=o??B,c=-1):m[1]===void 0?c=-2:(c=r.lastIndex-m[2].length,h=m[1],r=m[3]===void 0?w:m[3]==='"'?we:Ee):r===we||r===Ee?r=w:r===ye||r===be?r=B:(r=w,o=void 0);let b=r===w&&i[l+1].startsWith("/>")?" ":"";n+=r===B?a+Ke:c>=0?(s.push(h),a.slice(0,c)+de+a.slice(c)+y+b):a+y+(c===-2?l:b)}return[Le(i,n+(i[t]||"<?>")+(e===2?"</svg>":"")),s]},q=class i{constructor({strings:e,_$litType$:t},s){let o;this.parts=[];let n=0,r=0,l=e.length-1,a=this.parts,[h,m]=Ue(e,t);if(this.el=i.createElement(h,s),S.currentNode=this.el.content,t===2){let c=this.el.content.firstChild;c.replaceWith(...c.childNodes)}for(;(o=S.nextNode())!==null&&a.length<l;){if(o.nodeType===1){if(o.hasAttributes())for(let c of o.getAttributeNames())if(c.endsWith(de)){let _=m[r++],b=o.getAttribute(c).split(y),Y=/([.?@])?(.*)/.exec(_);a.push({type:1,index:n,name:Y[2],strings:b,ctor:Y[1]==="."?X:Y[1]==="?"?ee:Y[1]==="@"?te:R}),o.removeAttribute(c)}else c.startsWith(y)&&(a.push({type:6,index:n}),o.removeAttribute(c));if(Te.test(o.tagName)){let c=o.textContent.split(y),_=c.length-1;if(_>0){o.textContent=Z?Z.emptyScript:"";for(let b=0;b<_;b++)o.append(c[b],j()),S.nextNode(),a.push({type:2,index:++n});o.append(c[_],j())}}}else if(o.nodeType===8)if(o.data===ue)a.push({type:2,index:n});else{let c=-1;for(;(c=o.data.indexOf(y,c+1))!==-1;)a.push({type:7,index:n}),c+=y.length-1}n++}}static createElement(e,t){let s=x.createElement("template");return s.innerHTML=e,s}};function T(i,e,t=i,s){if(e===C)return e;let o=s!==void 0?t._$Co?.[s]:t._$Cl,n=z(e)?void 0:e._$litDirective$;return o?.constructor!==n&&(o?._$AO?.(!1),n===void 0?o=void 0:(o=new n(i),o._$AT(i,t,s)),s!==void 0?(t._$Co??=[])[s]=o:t._$Cl=o),o!==void 0&&(e=T(i,o._$AS(i,e.values),o,s)),e}var J=class{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){let{el:{content:t},parts:s}=this._$AD,o=(e?.creationScope??x).importNode(t,!0);S.currentNode=o;let n=S.nextNode(),r=0,l=0,a=s[0];for(;a!==void 0;){if(r===a.index){let h;a.type===2?h=new U(n,n.nextSibling,this,e):a.type===1?h=new a.ctor(n,a.name,a.strings,this,e):a.type===6&&(h=new se(n,this,e)),this._$AV.push(h),a=s[++l]}r!==a?.index&&(n=S.nextNode(),r++)}return S.currentNode=x,o}p(e){let t=0;for(let s of this._$AV)s!==void 0&&(s.strings!==void 0?(s._$AI(e,s,t),t+=s.strings.length-2):s._$AI(e[t])),t++}},U=class i{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(e,t,s,o){this.type=2,this._$AH=d,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=s,this.options=o,this._$Cv=o?.isConnected??!0}get parentNode(){let e=this._$AA.parentNode,t=this._$AM;return t!==void 0&&e?.nodeType===11&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=T(this,e,t),z(e)?e===d||e==null||e===""?(this._$AH!==d&&this._$AR(),this._$AH=d):e!==this._$AH&&e!==C&&this._(e):e._$litType$!==void 0?this.$(e):e.nodeType!==void 0?this.T(e):Ce(e)?this.k(e):this._(e)}S(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}T(e){this._$AH!==e&&(this._$AR(),this._$AH=this.S(e))}_(e){this._$AH!==d&&z(this._$AH)?this._$AA.nextSibling.data=e:this.T(x.createTextNode(e)),this._$AH=e}$(e){let{values:t,_$litType$:s}=e,o=typeof s=="number"?this._$AC(e):(s.el===void 0&&(s.el=q.createElement(Le(s.h,s.h[0]),this.options)),s);if(this._$AH?._$AD===o)this._$AH.p(t);else{let n=new J(o,this),r=n.u(this.options);n.p(t),this.T(r),this._$AH=n}}_$AC(e){let t=Se.get(e.strings);return t===void 0&&Se.set(e.strings,t=new q(e)),t}k(e){xe(this._$AH)||(this._$AH=[],this._$AR());let t=this._$AH,s,o=0;for(let n of e)o===t.length?t.push(s=new i(this.S(j()),this.S(j()),this,this.options)):s=t[o],s._$AI(n),o++;o<t.length&&(this._$AR(s&&s._$AB.nextSibling,o),t.length=o)}_$AR(e=this._$AA.nextSibling,t){for(this._$AP?.(!1,!0,t);e&&e!==this._$AB;){let s=e.nextSibling;e.remove(),e=s}}setConnected(e){this._$AM===void 0&&(this._$Cv=e,this._$AP?.(e))}},R=class{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(e,t,s,o,n){this.type=1,this._$AH=d,this._$AN=void 0,this.element=e,this.name=t,this._$AM=o,this.options=n,s.length>2||s[0]!==""||s[1]!==""?(this._$AH=Array(s.length-1).fill(new String),this.strings=s):this._$AH=d}_$AI(e,t=this,s,o){let n=this.strings,r=!1;if(n===void 0)e=T(this,e,t,0),r=!z(e)||e!==this._$AH&&e!==C,r&&(this._$AH=e);else{let l=e,a,h;for(e=n[0],a=0;a<n.length-1;a++)h=T(this,l[s+a],t,a),h===C&&(h=this._$AH[a]),r||=!z(h)||h!==this._$AH[a],h===d?e=d:e!==d&&(e+=(h??"")+n[a+1]),this._$AH[a]=h}r&&!o&&this.j(e)}j(e){e===d?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??"")}},X=class extends R{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===d?void 0:e}},ee=class extends R{constructor(){super(...arguments),this.type=4}j(e){this.element.toggleAttribute(this.name,!!e&&e!==d)}},te=class extends R{constructor(e,t,s,o,n){super(e,t,s,o,n),this.type=5}_$AI(e,t=this){if((e=T(this,e,t,0)??d)===C)return;let s=this._$AH,o=e===d&&s!==d||e.capture!==s.capture||e.once!==s.once||e.passive!==s.passive,n=e!==d&&(s===d||o);o&&this.element.removeEventListener(this.name,this,s),n&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){typeof this._$AH=="function"?this._$AH.call(this.options?.host??this.element,e):this._$AH.handleEvent(e)}},se=class{constructor(e,t,s){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=s}get _$AU(){return this._$AM._$AU}_$AI(e){T(this,e)}},Me={P:de,A:y,C:ue,M:1,L:Ue,R:J,D:Ce,V:T,I:U,H:R,N:ee,U:te,B:X,F:se},Ge=he.litHtmlPolyfillSupport;Ge?.(q,U),(he.litHtmlVersions??=[]).push("3.1.3");var Ne=(i,e,t)=>{let s=t?.renderBefore??e,o=s._$litPart$;if(o===void 0){let n=t?.renderBefore??null;s._$litPart$=o=new U(e.insertBefore(j(),n),n,void 0,t??{})}return o._$AI(i),o};var f=class extends A{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){let e=super.createRenderRoot();return this.renderOptions.renderBefore??=e.firstChild,e}update(e){let t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=Ne(t,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return C}};f._$litElement$=!0,f.finalized=!0,globalThis.litElementHydrateSupport?.({LitElement:f});var Qe=globalThis.litElementPolyfillSupport;Qe?.({LitElement:f});(globalThis.litElementVersions??=[]).push("4.0.5");var g=i=>(e,t)=>{t!==void 0?t.addInitializer(()=>{customElements.define(i,e)}):customElements.define(i,e)};var{I:wt}=Me;var He=i=>i.strings===void 0;var Pe={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},pe=i=>(...e)=>({_$litDirective$:i,values:e}),ie=class{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,t,s){this._$Ct=e,this._$AM=t,this._$Ci=s}_$AS(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}};var V=(i,e)=>{let t=i._$AN;if(t===void 0)return!1;for(let s of t)s._$AO?.(e,!1),V(s,e);return!0},oe=i=>{let e,t;do{if((e=i._$AM)===void 0)break;t=e._$AN,t.delete(i),i=e}while(t?.size===0)},Ie=i=>{for(let e;e=i._$AM;i=e){let t=e._$AN;if(t===void 0)e._$AN=t=new Set;else if(t.has(i))break;t.add(i),Xe(e)}};function Ze(i){this._$AN!==void 0?(oe(this),this._$AM=i,Ie(this)):this._$AM=i}function Je(i,e=!1,t=0){let s=this._$AH,o=this._$AN;if(o!==void 0&&o.size!==0)if(e)if(Array.isArray(s))for(let n=t;n<s.length;n++)V(s[n],!1),oe(s[n]);else s!=null&&(V(s,!1),oe(s));else V(this,i)}var Xe=i=>{i.type==Pe.CHILD&&(i._$AP??=Je,i._$AQ??=Ze)},ne=class extends ie{constructor(){super(...arguments),this._$AN=void 0}_$AT(e,t,s){super._$AT(e,t,s),Ie(this),this.isConnected=e._$AU}_$AO(e,t=!0){e!==this.isConnected&&(this.isConnected=e,e?this.reconnected?.():this.disconnected?.()),t&&(V(this,e),oe(this))}setValue(e){if(He(this._$Ct))this._$Ct._$AI(e,this);else{let t=[...this._$Ct._$AH];t[this._$Ci]=e,this._$Ct._$AI(t,this,0)}}disconnected(){}reconnected(){}};var u=()=>new fe,fe=class{},me=new WeakMap,p=pe(class extends ne{render(i){return d}update(i,[e]){let t=e!==this.Y;return t&&this.Y!==void 0&&this.rt(void 0),(t||this.lt!==this.ct)&&(this.Y=e,this.ht=i.options?.host,this.rt(this.ct=i.element)),d}rt(i){if(typeof this.Y=="function"){let e=this.ht??globalThis,t=me.get(e);t===void 0&&(t=new WeakMap,me.set(e,t)),t.get(this.Y)!==void 0&&this.Y.call(this.ht,void 0),t.set(this.Y,i),i!==void 0&&this.Y.call(this.ht,i)}else this.Y.value=i}get lt(){return typeof this.Y=="function"?me.get(this.ht??globalThis)?.get(this.Y):this.Y?.value}disconnected(){this.lt===this.ct&&this.rt(void 0)}reconnected(){this.rt(this.ct)}});var et={attribute:!0,type:String,converter:D,reflect:!1,hasChanged:Q},tt=(i=et,e,t)=>{let{kind:s,metadata:o}=t,n=globalThis.litPropertyMetadata.get(o);if(n===void 0&&globalThis.litPropertyMetadata.set(o,n=new Map),n.set(t.name,i),s==="accessor"){let{name:r}=t;return{set(l){let a=e.get.call(this);e.set.call(this,l),this.requestUpdate(r,a,i)},init(l){return l!==void 0&&this.P(r,void 0,i),l}}}if(s==="setter"){let{name:r}=t;return function(l){let a=this[r];e.call(this,l),this.requestUpdate(r,a,i)}}throw Error("Unsupported decorator location: "+s)};function Oe(i){return(e,t)=>typeof t=="object"?tt(i,e,t):((s,o,n)=>{let r=o.hasOwnProperty(n);return o.constructor.createProperty(n,r?{...s,wrapped:!0}:s),r?Object.getOwnPropertyDescriptor(o,n):void 0})(i,e,t)}function M(i){return Oe({...i,state:!0,attribute:!1})}var N=class extends f{constructor(){super(...arguments);this.userList=[];this.createRenderRoot=()=>this}connectedCallback(){super.connectedCallback(),this.loadUsers()}async loadUsers(){let t=await window.loadingController.create({message:"Cargando ..."});await t.present(),this.userList=[];let s=await window.connectors.profile.info(),o=await window.connectors.users.list();this.userList=o.filter(n=>n.uid!==s.uid),await t.dismiss()}delete(t){let s=this.loadUsers.bind(this);window.alertController.create({header:"Eliminar usuario",subHeader:"\xBFEstas seguro(a) que quieres eliminar este usuario?",message:"Todos los datos de van a eliminar, incluyendo archivos, acceso al sistema y asignaci\xF3n de aplicaciones.",buttons:["No",{role:"cancel",text:"Si",cssClass:"delete-button",async handler(){let o=await window.loadingController.create({message:"Eliminando ..."});await o.present(),await window.connectors.users.delete(t),await o.dismiss(),await s()}}]}).then(o=>o.present())}render(){return v`
      <style>
        .user-item {
          height: 100%;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          align-items: flex-start;
          position: relative;
        }
        .user-item .buttons {
          display: flex;
          justify-content: flex-end;
          width: 100%;
          position: absolute;
        }
        .delete-button {
          outline: 1px solid var(--ion-color-danger) !important;
          color: var(--ion-color-danger) !important;
        }
      </style>
      <ion-grid>
        <ion-row>
          ${this.userList.map(t=>v`
            <ion-col
              size="12"
              size-sm="6"
              size-md="4"
              size-lg="3"
            >
              <ion-card class="user-item">
                <ion-card-header>
                  <ion-card-title>${t.name}</ion-card-title>
                  <ion-card-subtitle>${t.full_name}</ion-card-subtitle>
                </ion-card-header>
                <div class="buttons">
                  <ion-button fill="clear" @click=${()=>this.dispatchEvent(new CustomEvent("apps",{detail:t}))}>
                    <ion-icon slot="icon-only" name="apps-outline"></ion-icon>
                  </ion-button>
                  <ion-button fill="clear" @click=${()=>this.dispatchEvent(new CustomEvent("edit",{detail:t}))}>
                    <ion-icon slot="icon-only" name="create-outline"></ion-icon>
                  </ion-button>
                  <ion-button fill="clear" color="danger" @click=${()=>this.delete(t.uid)}>
                    <ion-icon slot="icon-only" name="trash-outline"></ion-icon>
                  </ion-button>
                </div>
              </ion-card>
            </ion-col>
          `)}
        </ion-row>
      </ion-grid>
    `}};$([M()],N.prototype,"userList",2),N=$([g("user-list")],N);var H=class extends f{constructor(){super(...arguments);this.modal=u();this.userNameRef=u();this.fullNameRef=u();this.emailRef=u();this.phoneRef=u();this.passwordRef=u();this.createRenderRoot=()=>this}async save(){let t=this.userNameRef.value?.value?.toString().trim(),s=this.fullNameRef.value?.value?.toString().trim(),o=this.emailRef.value?.value?.toString().trim()||"",n=this.phoneRef.value?.value?.toString().trim()||"",r=this.passwordRef.value?.value?.toString().trim();if(!t){this.userNameRef.value?.setAttribute("error-text","Campo requerido"),this.userNameRef.value?.classList.add("ion-invalid"),this.userNameRef.value?.setFocus();return}if(!s){this.fullNameRef.value?.classList.add("ion-invalid"),this.fullNameRef.value?.setFocus();return}if(!r){this.passwordRef.value?.classList.add("ion-invalid"),this.passwordRef.value?.setFocus();return}let l={name:t,full_name:s,email:o,phone:n,password:r},a=await window.loadingController.create({message:"Creando usuario ..."});await a.present();let h=await window.connectors.users.create(l);if(await a.dismiss(),typeof h=="object"&&h.code){if(h.code==="user-already-exists"){this.userNameRef.value?.setAttribute("error-text","Este usuario ya existe"),this.userNameRef.value?.classList.add("ion-invalid"),this.userNameRef.value?.setFocus();return}(await window.alertController.create({header:"No se puede crear el usuario.",message:h.message,buttons:["Aceptar"]})).present();return}this.modal.value?.dismiss(),this.dispatchEvent(new CustomEvent("save"))}reset(){this.userNameRef.value.value="",this.fullNameRef.value.value="",this.emailRef.value.value="",this.phoneRef.value.value="",this.passwordRef.value.value=""}render(){return v`
      <ion-fab slot="fixed" vertical="bottom" horizontal="end">
        <ion-fab-button color="light" @click=${()=>this.modal.value?.present()}>
          <ion-icon name="person-add"></ion-icon>
        </ion-fab-button>
      </ion-fab>
      <ion-modal
        ${p(this.modal)}
        @ionModalDidDismiss=${this.reset.bind(this)}
      >
        <ion-header>
          <ion-toolbar>
            <ion-title>Nuevo usuario</ion-title>
            <ion-buttons slot="end">
              <ion-button @click=${()=>this.modal.value?.dismiss()}>
                <ion-icon slot="icon-only" name="close"></ion-icon>
              </ion-button>
            </ion-buttons>
          </ion-toolbar>
        </ion-header>
        <ion-content class="ion-padding">
          <ion-list inset>
            <ion-item>
              <ion-input
                ${p(this.userNameRef)}
                class="ion-touched"
                label="Nombre de usuario"
                label-placement="floating"
                @ionBlur=${()=>this.userNameRef.value?.classList.remove("ion-invalid")}
              ></ion-input>
            </ion-item>
            <ion-item>
              <ion-input
                ${p(this.fullNameRef)}
                class="ion-touched"
                label="Nombre completo"
                label-placement="floating"
                @ionBlur=${()=>this.fullNameRef.value?.classList.remove("ion-invalid")}
              ></ion-input>
            </ion-item>
            <ion-item>
              <ion-input
                ${p(this.emailRef)}
                label="Correo electrónico"
                label-placement="floating"
                type="email"
              ></ion-input>
            </ion-item>
            <ion-item>
              <ion-input
                ${p(this.phoneRef)}
                label="Teléfono"
                label-placement="floating"
                type="tel"
              ></ion-input>
            </ion-item>
            <ion-item>
              <ion-input
                ${p(this.passwordRef)}
                class="ion-touched"
                label="Contraseña"
                label-placement="floating"
                type="password"
                @ionBlur=${()=>this.passwordRef.value?.classList.remove("ion-invalid")}
              ></ion-input>
            </ion-item>
            <ion-button @click=${this.save.bind(this)} color="dark" strong fill="clear" expand="full">Guardar</ion-button>
          </ion-list>
        </ion-content>
      </ion-modal>
    `}};H.styles=E`
    :host {
      display: contents;
    }
  `,H=$([g("new-user")],H);var L=class extends f{constructor(){super(...arguments);this.name="";this.modal=u();this.fullNameRef=u();this.emailRef=u();this.phoneRef=u();this.uid=NaN;this.createRenderRoot=()=>this}setUser(t){this.uid=t.uid,this.name=t.name,this.fullNameRef.value.value=t.full_name,this.emailRef.value.value=t.email,this.phoneRef.value.value=t.phone,this.modal.value?.present()}async save(){let t=this.fullNameRef.value?.value?.toString().trim(),s=this.emailRef.value?.value?.toString().trim(),o=this.phoneRef.value?.value?.toString().trim();if(!t){this.fullNameRef.value?.classList.add("ion-invalid"),this.fullNameRef.value?.setFocus();return}let n={full_name:t,email:s,phone:o},r=await window.loadingController.create({message:"Actualizando usuario ..."});await r.present();let l=await window.connectors.users.update(this.uid,n);if(await r.dismiss(),typeof l=="object"&&l.code){(await window.alertController.create({header:"No se puede crear el usuario.",message:l.message,buttons:["Aceptar"]})).present();return}this.modal.value?.dismiss(),this.dispatchEvent(new CustomEvent("save"))}reset(){this.uid=NaN,this.name="",this.fullNameRef.value.value="",this.emailRef.value.value="",this.phoneRef.value.value="",this.dispatchEvent(new CustomEvent("close"))}render(){return v`
      <ion-modal
        ${p(this.modal)}
        @ionModalDidDismiss=${this.reset.bind(this)}
      >
        <ion-header>
          <ion-toolbar>
            <ion-title>Editar usuario - ${this.name}</ion-title>
            <ion-buttons slot="end">
              <ion-button @click=${()=>this.modal.value?.dismiss().then(()=>this.uid=NaN)}>
                <ion-icon slot="icon-only" name="close"></ion-icon>
              </ion-button>
            </ion-buttons>
          </ion-toolbar>
        </ion-header>
        <ion-content class="ion-padding">
          <ion-list inset>
            <ion-item>
              <ion-input
                ${p(this.fullNameRef)}
                class="ion-touched"
                label="Nombre completo"
                label-placement="floating"
                @ionBlur=${()=>this.fullNameRef.value?.classList.remove("ion-invalid")}
              ></ion-input>
            </ion-item>
            <ion-item>
              <ion-input
                ${p(this.emailRef)}
                label="Correo electrónico"
                label-placement="floating"
                type="email"
              ></ion-input>
            </ion-item>
            <ion-item>
              <ion-input
                ${p(this.phoneRef)}
                label="Teléfono"
                label-placement="floating"
                type="tel"
              ></ion-input>
            </ion-item>
            <ion-button @click=${this.save.bind(this)} color="dark" strong fill="clear" expand="full">Guardar</ion-button>
          </ion-list>
        </ion-content>
      </ion-modal>
    `}};L.styles=E`
    :host {
      display: contents;
    }
  `,$([M()],L.prototype,"name",2),L=$([g("edit-user")],L);var P=class extends f{constructor(){super(...arguments);this.apps=[];this.modal=u()}async setUser(t){this.apps=[];let s=await window.loadingController.create({message:"Cargando lista de apps ..."});await s.present(),this.user=t;let o=await window.connectors.apps.listByUID(t.uid);this.apps=(await window.connectors.apps.list()).map(n=>({...n,assign:o.findIndex(r=>n.package_name===r.package_name)>-1})),await s.dismiss(),await this.modal.value?.present()}async changeAssign(t,s){let o=s?"Asignando ...":"Quitando asignaci\xF3n ...",n=await window.loadingController.create({message:o});await n.present(),s?await window.connectors.users.assignApp(this.user?.uid||NaN,t):await window.connectors.users.unassignApp(this.user?.uid||NaN,t),await n.dismiss(),this.setUser(this.user)}handlerOnDismiss(){this.user=void 0,this.apps=[]}render(){return v`
      <ion-modal ${p(this.modal)} @ionModalWillDismiss=${this.handlerOnDismiss.bind(this)}>
        <ion-header>
          <ion-toolbar>
            <ion-title>Apps - ${this.user?.name}</ion-title>
            <ion-buttons slot="end">
              <ion-button @click=${()=>this.modal.value?.dismiss()}>
                <ion-icon slot="icon-only" name="close"></ion-icon>
              </ion-button>
            </ion-buttons>
          </ion-toolbar>
        </ion-header>
        <ion-content class="ion-padding">
          <style>
            ion-note {
              display: block;
            }
          </style>
          <ion-list inset>
            ${this.apps.length===0?v`
              <ion-item>
                <ion-label class="ion-text-center">No hay apps instaladas.</ion-label>
              </ion-item>
            `:""}
            ${this.apps.map(t=>v`
              <ion-item>
                <ion-toggle ?checked=${t.assign} @ionChange=${()=>this.changeAssign(t.package_name,!t.assign)}>
                  <ion-label>${t.title}</ion-label>
                  <ion-note color="medium">${t.package_name}</ion-note>
                </ion-toggle>
              </ion-item>
            `)}
          </ion-list>
        </ion-content>
      </ion-modal>
    `}};$([M()],P.prototype,"apps",2),P=$([g("apps-user")],P);var I=class extends f{constructor(){super(...arguments);this.userListElement=u();this.editUserElement=u();this.appsUserElement=u();this.createRenderRoot=()=>this}render(){return v`
      <ion-app>
        <ion-header>
          <ion-toolbar>
            <ion-title>Usuarios</ion-title>
            <ion-buttons slot="end">
              <ion-button @click=${()=>this.userListElement.value?.loadUsers()}>
                <ion-icon slot="icon-only" name="refresh"></ion-icon>
              </ion-button>
            </ion-buttons>
          </ion-toolbar>
        </ion-header>
        <ion-content class="ion-padding">
          <user-list
            ${p(this.userListElement)}
            @edit=${t=>this.editUserElement.value?.setUser(t.detail)}
            @apps=${t=>this.appsUserElement.value?.setUser(t.detail)}
          ></user-list>
          <new-user
            @save=${()=>this.userListElement.value?.loadUsers()}
          ></new-user>
          <edit-user
            ${p(this.editUserElement)}
            @save=${()=>this.userListElement.value?.loadUsers()}
          ></edit-user>
          <apps-user
            ${p(this.appsUserElement)}
            @save=${()=>this.userListElement.value?.loadUsers()}
          ></apps-user>
        </ion-content>
      </ion-app>
    `}};I.styles=E`
    :host {
      display: contents;
    }
  `,I=$([g("app-root")],I);document.addEventListener("onReady",async()=>{document.body.innerHTML="<app-root></app-root>"});export{I as default};
/*! Bundled license information:

@lit/reactive-element/css-tag.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/reactive-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/lit-html.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-element/lit-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/is-server.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/custom-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/directive-helpers.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/directive.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/async-directive.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/directives/ref.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/property.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/state.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/event-options.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/base.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query-all.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query-async.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query-assigned-elements.js:
  (**
   * @license
   * Copyright 2021 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query-assigned-nodes.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
