var It=Object.defineProperty;var Ot=Object.getOwnPropertyDescriptor;var _=(o,t,e,i)=>{for(var s=i>1?void 0:i?Ot(t,e):t,n=o.length-1,r;n>=0;n--)(r=o[n])&&(s=(i?r(t,e,s):r(s))||s);return i&&s&&It(t,e,s),s};var V=globalThis,W=V.ShadowRoot&&(V.ShadyCSS===void 0||V.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,mt=Symbol(),ut=new WeakMap,Y=class{constructor(t,e,i){if(this._$cssResult$=!0,i!==mt)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=e}get styleSheet(){let t=this.o,e=this.t;if(W&&t===void 0){let i=e!==void 0&&e.length===1;i&&(t=ut.get(e)),t===void 0&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),i&&ut.set(e,t))}return t}toString(){return this.cssText}},_t=o=>new Y(typeof o=="string"?o:o+"",void 0,mt);var nt=(o,t)=>{if(W)o.adoptedStyleSheets=t.map(e=>e instanceof CSSStyleSheet?e:e.styleSheet);else for(let e of t){let i=document.createElement("style"),s=V.litNonce;s!==void 0&&i.setAttribute("nonce",s),i.textContent=e.cssText,o.appendChild(i)}},q=W?o=>o:o=>o instanceof CSSStyleSheet?(t=>{let e="";for(let i of t.cssRules)e+=i.cssText;return _t(e)})(o):o;var{is:Dt,defineProperty:kt,getOwnPropertyDescriptor:zt,getOwnPropertyNames:Bt,getOwnPropertySymbols:Ft,getPrototypeOf:jt}=Object,K=globalThis,$t=K.trustedTypes,Vt=$t?$t.emptyScript:"",Yt=K.reactiveElementPolyfillSupport,H=(o,t)=>o,N={toAttribute(o,t){switch(t){case Boolean:o=o?Vt:null;break;case Object:case Array:o=o==null?o:JSON.stringify(o)}return o},fromAttribute(o,t){let e=o;switch(t){case Boolean:e=o!==null;break;case Number:e=o===null?null:Number(o);break;case Object:case Array:try{e=JSON.parse(o)}catch{e=null}}return e}},G=(o,t)=>!Dt(o,t),ft={attribute:!0,type:String,converter:N,reflect:!1,hasChanged:G};Symbol.metadata??=Symbol("metadata"),K.litPropertyMetadata??=new WeakMap;var A=class extends HTMLElement{static addInitializer(t){this._$Ei(),(this.l??=[]).push(t)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(t,e=ft){if(e.state&&(e.attribute=!1),this._$Ei(),this.elementProperties.set(t,e),!e.noAccessor){let i=Symbol(),s=this.getPropertyDescriptor(t,i,e);s!==void 0&&kt(this.prototype,t,s)}}static getPropertyDescriptor(t,e,i){let{get:s,set:n}=zt(this.prototype,t)??{get(){return this[e]},set(r){this[e]=r}};return{get(){return s?.call(this)},set(r){let c=s?.call(this);n.call(this,r),this.requestUpdate(t,c,i)},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)??ft}static _$Ei(){if(this.hasOwnProperty(H("elementProperties")))return;let t=jt(this);t.finalize(),t.l!==void 0&&(this.l=[...t.l]),this.elementProperties=new Map(t.elementProperties)}static finalize(){if(this.hasOwnProperty(H("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(H("properties"))){let e=this.properties,i=[...Bt(e),...Ft(e)];for(let s of i)this.createProperty(s,e[s])}let t=this[Symbol.metadata];if(t!==null){let e=litPropertyMetadata.get(t);if(e!==void 0)for(let[i,s]of e)this.elementProperties.set(i,s)}this._$Eh=new Map;for(let[e,i]of this.elementProperties){let s=this._$Eu(e,i);s!==void 0&&this._$Eh.set(s,e)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(t){let e=[];if(Array.isArray(t)){let i=new Set(t.flat(1/0).reverse());for(let s of i)e.unshift(q(s))}else t!==void 0&&e.push(q(t));return e}static _$Eu(t,e){let i=e.attribute;return i===!1?void 0:typeof i=="string"?i:typeof t=="string"?t.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(t=>this.enableUpdating=t),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(t=>t(this))}addController(t){(this._$EO??=new Set).add(t),this.renderRoot!==void 0&&this.isConnected&&t.hostConnected?.()}removeController(t){this._$EO?.delete(t)}_$E_(){let t=new Map,e=this.constructor.elementProperties;for(let i of e.keys())this.hasOwnProperty(i)&&(t.set(i,this[i]),delete this[i]);t.size>0&&(this._$Ep=t)}createRenderRoot(){let t=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return nt(t,this.constructor.elementStyles),t}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(t=>t.hostConnected?.())}enableUpdating(t){}disconnectedCallback(){this._$EO?.forEach(t=>t.hostDisconnected?.())}attributeChangedCallback(t,e,i){this._$AK(t,i)}_$EC(t,e){let i=this.constructor.elementProperties.get(t),s=this.constructor._$Eu(t,i);if(s!==void 0&&i.reflect===!0){let n=(i.converter?.toAttribute!==void 0?i.converter:N).toAttribute(e,i.type);this._$Em=t,n==null?this.removeAttribute(s):this.setAttribute(s,n),this._$Em=null}}_$AK(t,e){let i=this.constructor,s=i._$Eh.get(t);if(s!==void 0&&this._$Em!==s){let n=i.getPropertyOptions(s),r=typeof n.converter=="function"?{fromAttribute:n.converter}:n.converter?.fromAttribute!==void 0?n.converter:N;this._$Em=s,this[s]=r.fromAttribute(e,n.type),this._$Em=null}}requestUpdate(t,e,i){if(t!==void 0){if(i??=this.constructor.getPropertyOptions(t),!(i.hasChanged??G)(this[t],e))return;this.P(t,e,i)}this.isUpdatePending===!1&&(this._$ES=this._$ET())}P(t,e,i){this._$AL.has(t)||this._$AL.set(t,e),i.reflect===!0&&this._$Em!==t&&(this._$Ej??=new Set).add(t)}async _$ET(){this.isUpdatePending=!0;try{await this._$ES}catch(e){Promise.reject(e)}let t=this.scheduleUpdate();return t!=null&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(let[s,n]of this._$Ep)this[s]=n;this._$Ep=void 0}let i=this.constructor.elementProperties;if(i.size>0)for(let[s,n]of i)n.wrapped!==!0||this._$AL.has(s)||this[s]===void 0||this.P(s,this[s],n)}let t=!1,e=this._$AL;try{t=this.shouldUpdate(e),t?(this.willUpdate(e),this._$EO?.forEach(i=>i.hostUpdate?.()),this.update(e)):this._$EU()}catch(i){throw t=!1,this._$EU(),i}t&&this._$AE(e)}willUpdate(t){}_$AE(t){this._$EO?.forEach(e=>e.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t)}_$EU(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(t){return!0}update(t){this._$Ej&&=this._$Ej.forEach(e=>this._$EC(e,this[e])),this._$EU()}updated(t){}firstUpdated(t){}};A.elementStyles=[],A.shadowRootOptions={mode:"open"},A[H("elementProperties")]=new Map,A[H("finalized")]=new Map,Yt?.({ReactiveElement:A}),(K.reactiveElementVersions??=[]).push("2.0.4");var at=globalThis,Q=at.trustedTypes,At=Q?Q.createPolicy("lit-html",{createHTML:o=>o}):void 0,lt="$lit$",g=`lit$${Math.random().toFixed(9).slice(2)}$`,ct="?"+g,Wt=`<${ct}>`,w=document,O=()=>w.createComment(""),D=o=>o===null||typeof o!="object"&&typeof o!="function",bt=Array.isArray,wt=o=>bt(o)||typeof o?.[Symbol.iterator]=="function",rt=`[ 	
\f\r]`,I=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,gt=/-->/g,vt=/>/g,y=RegExp(`>|${rt}(?:([^\\s"'>=/]+)(${rt}*=${rt}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),Et=/'/g,St=/"/g,Ct=/^(?:script|style|textarea|title)$/i,Pt=o=>(t,...e)=>({_$litType$:o,strings:t,values:e}),m=Pt(1),re=Pt(2),C=Symbol.for("lit-noChange"),h=Symbol.for("lit-nothing"),yt=new WeakMap,b=w.createTreeWalker(w,129);function Tt(o,t){if(!Array.isArray(o)||!o.hasOwnProperty("raw"))throw Error("invalid template strings array");return At!==void 0?At.createHTML(t):t}var Lt=(o,t)=>{let e=o.length-1,i=[],s,n=t===2?"<svg>":"",r=I;for(let c=0;c<e;c++){let a=o[c],p,d,l=-1,f=0;for(;f<a.length&&(r.lastIndex=f,d=r.exec(a),d!==null);)f=r.lastIndex,r===I?d[1]==="!--"?r=gt:d[1]!==void 0?r=vt:d[2]!==void 0?(Ct.test(d[2])&&(s=RegExp("</"+d[2],"g")),r=y):d[3]!==void 0&&(r=y):r===y?d[0]===">"?(r=s??I,l=-1):d[1]===void 0?l=-2:(l=r.lastIndex-d[2].length,p=d[1],r=d[3]===void 0?y:d[3]==='"'?St:Et):r===St||r===Et?r=y:r===gt||r===vt?r=I:(r=y,s=void 0);let v=r===y&&o[c+1].startsWith("/>")?" ":"";n+=r===I?a+Wt:l>=0?(i.push(p),a.slice(0,l)+lt+a.slice(l)+g+v):a+g+(l===-2?c:v)}return[Tt(o,n+(o[e]||"<?>")+(t===2?"</svg>":"")),i]},k=class o{constructor({strings:t,_$litType$:e},i){let s;this.parts=[];let n=0,r=0,c=t.length-1,a=this.parts,[p,d]=Lt(t,e);if(this.el=o.createElement(p,i),b.currentNode=this.el.content,e===2){let l=this.el.content.firstChild;l.replaceWith(...l.childNodes)}for(;(s=b.nextNode())!==null&&a.length<c;){if(s.nodeType===1){if(s.hasAttributes())for(let l of s.getAttributeNames())if(l.endsWith(lt)){let f=d[r++],v=s.getAttribute(l).split(g),j=/([.?@])?(.*)/.exec(f);a.push({type:1,index:n,name:j[2],strings:v,ctor:j[1]==="."?J:j[1]==="?"?X:j[1]==="@"?tt:T}),s.removeAttribute(l)}else l.startsWith(g)&&(a.push({type:6,index:n}),s.removeAttribute(l));if(Ct.test(s.tagName)){let l=s.textContent.split(g),f=l.length-1;if(f>0){s.textContent=Q?Q.emptyScript:"";for(let v=0;v<f;v++)s.append(l[v],O()),b.nextNode(),a.push({type:2,index:++n});s.append(l[f],O())}}}else if(s.nodeType===8)if(s.data===ct)a.push({type:2,index:n});else{let l=-1;for(;(l=s.data.indexOf(g,l+1))!==-1;)a.push({type:7,index:n}),l+=g.length-1}n++}}static createElement(t,e){let i=w.createElement("template");return i.innerHTML=t,i}};function P(o,t,e=o,i){if(t===C)return t;let s=i!==void 0?e._$Co?.[i]:e._$Cl,n=D(t)?void 0:t._$litDirective$;return s?.constructor!==n&&(s?._$AO?.(!1),n===void 0?s=void 0:(s=new n(o),s._$AT(o,e,i)),i!==void 0?(e._$Co??=[])[i]=s:e._$Cl=s),s!==void 0&&(t=P(o,s._$AS(o,t.values),s,i)),t}var Z=class{constructor(t,e){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=e}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){let{el:{content:e},parts:i}=this._$AD,s=(t?.creationScope??w).importNode(e,!0);b.currentNode=s;let n=b.nextNode(),r=0,c=0,a=i[0];for(;a!==void 0;){if(r===a.index){let p;a.type===2?p=new L(n,n.nextSibling,this,t):a.type===1?p=new a.ctor(n,a.name,a.strings,this,t):a.type===6&&(p=new et(n,this,t)),this._$AV.push(p),a=i[++c]}r!==a?.index&&(n=b.nextNode(),r++)}return b.currentNode=w,s}p(t){let e=0;for(let i of this._$AV)i!==void 0&&(i.strings!==void 0?(i._$AI(t,i,e),e+=i.strings.length-2):i._$AI(t[e])),e++}},L=class o{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(t,e,i,s){this.type=2,this._$AH=h,this._$AN=void 0,this._$AA=t,this._$AB=e,this._$AM=i,this.options=s,this._$Cv=s?.isConnected??!0}get parentNode(){let t=this._$AA.parentNode,e=this._$AM;return e!==void 0&&t?.nodeType===11&&(t=e.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,e=this){t=P(this,t,e),D(t)?t===h||t==null||t===""?(this._$AH!==h&&this._$AR(),this._$AH=h):t!==this._$AH&&t!==C&&this._(t):t._$litType$!==void 0?this.$(t):t.nodeType!==void 0?this.T(t):wt(t)?this.k(t):this._(t)}S(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}T(t){this._$AH!==t&&(this._$AR(),this._$AH=this.S(t))}_(t){this._$AH!==h&&D(this._$AH)?this._$AA.nextSibling.data=t:this.T(w.createTextNode(t)),this._$AH=t}$(t){let{values:e,_$litType$:i}=t,s=typeof i=="number"?this._$AC(t):(i.el===void 0&&(i.el=k.createElement(Tt(i.h,i.h[0]),this.options)),i);if(this._$AH?._$AD===s)this._$AH.p(e);else{let n=new Z(s,this),r=n.u(this.options);n.p(e),this.T(r),this._$AH=n}}_$AC(t){let e=yt.get(t.strings);return e===void 0&&yt.set(t.strings,e=new k(t)),e}k(t){bt(this._$AH)||(this._$AH=[],this._$AR());let e=this._$AH,i,s=0;for(let n of t)s===e.length?e.push(i=new o(this.S(O()),this.S(O()),this,this.options)):i=e[s],i._$AI(n),s++;s<e.length&&(this._$AR(i&&i._$AB.nextSibling,s),e.length=s)}_$AR(t=this._$AA.nextSibling,e){for(this._$AP?.(!1,!0,e);t&&t!==this._$AB;){let i=t.nextSibling;t.remove(),t=i}}setConnected(t){this._$AM===void 0&&(this._$Cv=t,this._$AP?.(t))}},T=class{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(t,e,i,s,n){this.type=1,this._$AH=h,this._$AN=void 0,this.element=t,this.name=e,this._$AM=s,this.options=n,i.length>2||i[0]!==""||i[1]!==""?(this._$AH=Array(i.length-1).fill(new String),this.strings=i):this._$AH=h}_$AI(t,e=this,i,s){let n=this.strings,r=!1;if(n===void 0)t=P(this,t,e,0),r=!D(t)||t!==this._$AH&&t!==C,r&&(this._$AH=t);else{let c=t,a,p;for(t=n[0],a=0;a<n.length-1;a++)p=P(this,c[i+a],e,a),p===C&&(p=this._$AH[a]),r||=!D(p)||p!==this._$AH[a],p===h?t=h:t!==h&&(t+=(p??"")+n[a+1]),this._$AH[a]=p}r&&!s&&this.j(t)}j(t){t===h?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,t??"")}},J=class extends T{constructor(){super(...arguments),this.type=3}j(t){this.element[this.name]=t===h?void 0:t}},X=class extends T{constructor(){super(...arguments),this.type=4}j(t){this.element.toggleAttribute(this.name,!!t&&t!==h)}},tt=class extends T{constructor(t,e,i,s,n){super(t,e,i,s,n),this.type=5}_$AI(t,e=this){if((t=P(this,t,e,0)??h)===C)return;let i=this._$AH,s=t===h&&i!==h||t.capture!==i.capture||t.once!==i.once||t.passive!==i.passive,n=t!==h&&(i===h||s);s&&this.element.removeEventListener(this.name,this,i),n&&this.element.addEventListener(this.name,this,t),this._$AH=t}handleEvent(t){typeof this._$AH=="function"?this._$AH.call(this.options?.host??this.element,t):this._$AH.handleEvent(t)}},et=class{constructor(t,e,i){this.element=t,this.type=6,this._$AN=void 0,this._$AM=e,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(t){P(this,t)}},Rt={P:lt,A:g,C:ct,M:1,L:Lt,R:Z,D:wt,V:P,I:L,H:T,N:X,U:tt,B:J,F:et},qt=at.litHtmlPolyfillSupport;qt?.(k,L),(at.litHtmlVersions??=[]).push("3.1.3");var xt=(o,t,e)=>{let i=e?.renderBefore??t,s=i._$litPart$;if(s===void 0){let n=e?.renderBefore??null;i._$litPart$=s=new L(t.insertBefore(O(),n),n,void 0,e??{})}return s._$AI(o),s};var u=class extends A{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){let t=super.createRenderRoot();return this.renderOptions.renderBefore??=t.firstChild,t}update(t){let e=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=xt(e,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return C}};u._$litElement$=!0,u.finalized=!0,globalThis.litElementHydrateSupport?.({LitElement:u});var Kt=globalThis.litElementPolyfillSupport;Kt?.({LitElement:u});(globalThis.litElementVersions??=[]).push("4.0.5");var $=o=>(t,e)=>{e!==void 0?e.addInitializer(()=>{customElements.define(o,t)}):customElements.define(o,t)};var{I:ye}=Rt;var Ut=o=>o.strings===void 0;var Mt={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},ht=o=>(...t)=>({_$litDirective$:o,values:t}),it=class{constructor(t){}get _$AU(){return this._$AM._$AU}_$AT(t,e,i){this._$Ct=t,this._$AM=e,this._$Ci=i}_$AS(t,e){return this.update(t,e)}update(t,e){return this.render(...e)}};var z=(o,t)=>{let e=o._$AN;if(e===void 0)return!1;for(let i of e)i._$AO?.(t,!1),z(i,t);return!0},st=o=>{let t,e;do{if((t=o._$AM)===void 0)break;e=t._$AN,e.delete(o),o=t}while(e?.size===0)},Ht=o=>{for(let t;t=o._$AM;o=t){let e=t._$AN;if(e===void 0)t._$AN=e=new Set;else if(e.has(o))break;e.add(o),Zt(t)}};function Gt(o){this._$AN!==void 0?(st(this),this._$AM=o,Ht(this)):this._$AM=o}function Qt(o,t=!1,e=0){let i=this._$AH,s=this._$AN;if(s!==void 0&&s.size!==0)if(t)if(Array.isArray(i))for(let n=e;n<i.length;n++)z(i[n],!1),st(i[n]);else i!=null&&(z(i,!1),st(i));else z(this,o)}var Zt=o=>{o.type==Mt.CHILD&&(o._$AP??=Qt,o._$AQ??=Gt)},ot=class extends it{constructor(){super(...arguments),this._$AN=void 0}_$AT(t,e,i){super._$AT(t,e,i),Ht(this),this.isConnected=t._$AU}_$AO(t,e=!0){t!==this.isConnected&&(this.isConnected=t,t?this.reconnected?.():this.disconnected?.()),e&&(z(this,t),st(this))}setValue(t){if(Ut(this._$Ct))this._$Ct._$AI(t,this);else{let e=[...this._$Ct._$AH];e[this._$Ci]=t,this._$Ct._$AI(e,this,0)}}disconnected(){}reconnected(){}};var E=()=>new dt,dt=class{},pt=new WeakMap,S=ht(class extends ot{render(o){return h}update(o,[t]){let e=t!==this.Y;return e&&this.Y!==void 0&&this.rt(void 0),(e||this.lt!==this.ct)&&(this.Y=t,this.ht=o.options?.host,this.rt(this.ct=o.element)),h}rt(o){if(typeof this.Y=="function"){let t=this.ht??globalThis,e=pt.get(t);e===void 0&&(e=new WeakMap,pt.set(t,e)),e.get(this.Y)!==void 0&&this.Y.call(this.ht,void 0),e.set(this.Y,o),o!==void 0&&this.Y.call(this.ht,o)}else this.Y.value=o}get lt(){return typeof this.Y=="function"?pt.get(this.ht??globalThis)?.get(this.Y):this.Y?.value}disconnected(){this.lt===this.ct&&this.rt(void 0)}reconnected(){this.rt(this.ct)}});var Jt={attribute:!0,type:String,converter:N,reflect:!1,hasChanged:G},Xt=(o=Jt,t,e)=>{let{kind:i,metadata:s}=e,n=globalThis.litPropertyMetadata.get(s);if(n===void 0&&globalThis.litPropertyMetadata.set(s,n=new Map),n.set(e.name,o),i==="accessor"){let{name:r}=e;return{set(c){let a=t.get.call(this);t.set.call(this,c),this.requestUpdate(r,a,o)},init(c){return c!==void 0&&this.P(r,void 0,o),c}}}if(i==="setter"){let{name:r}=e;return function(c){let a=this[r];t.call(this,c),this.requestUpdate(r,a,o)}}throw Error("Unsupported decorator location: "+i)};function Nt(o){return(t,e)=>typeof e=="object"?Xt(o,t,e):((i,s,n)=>{let r=s.hasOwnProperty(n);return s.constructor.createProperty(n,r?{...i,wrapped:!0}:i),r?Object.getOwnPropertyDescriptor(s,n):void 0})(o,t,e)}function R(o){return Nt({...o,state:!0,attribute:!1})}var x=class extends u{constructor(){super(...arguments);this.apps=[];this.createRenderRoot=()=>this}connectedCallback(){super.connectedCallback(),this.loadApps()}async loadApps(){let e=await window.loadingController.create({message:"Cargando lista de aplicaciones ..."});await e.present(),this.apps=await window.connectors.apps.list(),await e.dismiss()}uninstall(e){let i=this.loadApps.bind(this);window.alertController.create({header:"Desinstalar app",message:"\xBFEst\xE1s seguro(a) que quieres desinstalar esta app?",buttons:["No",{text:"Si",cssClass:"delete-button",async handler(){let s=await window.loadingController.create({message:"Desinstalando ..."});await s.present(),await window.connectors.apps.uninstall(e),await s.dismiss(),i()}}]}).then(s=>s.present())}render(){return m`
      <style>
        .delete-button {
          outline: 1px solid var(--ion-color-danger) !important;
          color: var(--ion-color-danger) !important;
        }

        app-list ion-card {
          position: relative;
        }

        app-list ion-card .btn-remove {
          position: absolute;
          top: 0;
          right: 0;
        }
      </style>
      <ion-grid>
        <ion-row>
          ${this.apps.map(e=>m`
            <ion-col
              size="12"
              size-sm="6"
              size-md="12"
              size-lg="6"
              size-xl="4"
            >
              <ion-card>
                <ion-card-header>
                  <ion-card-title>${e.title}&nbsp;<ion-note>(${e.package_name})</ion-note></ion-card-title>
                  <ion-card-subtitle>${e.author}</ion-card-subtitle>
                </ion-card-header>
                <ion-card-content><p>${e.description}</p></ion-card-content>
                <ion-button class="btn-remove" fill="clear" color="danger" @click=${()=>this.uninstall(e.package_name)}>
                  <ion-icon slot="icon-only" name="remove-circle-outline"></ion-icon>
                </ion-button>
                <ion-button class="ion-float-right" fill="outline" @click=${()=>this.dispatchEvent(new CustomEvent("permissions",{detail:e}))}>Permisos</ion-button>
                <ion-button class="ion-float-right" fill="outline" @click=${()=>this.dispatchEvent(new CustomEvent("sources",{detail:e}))}>Fuentes</ion-button>
              </ion-card>
            </ion-col>
          `)}
        </ion-row>
      </ion-grid>
    `}};_([R()],x.prototype,"apps",2),x=_([$("app-list")],x);var B=class extends u{constructor(){super(...arguments);this.createRenderRoot=()=>this}selectFile(){let e=document.createElement("input");e.type="file",e.multiple=!1,e.accept="application/zip",e.addEventListener("change",async()=>{let i=e.files?.item(0),s=await window.loadingController.create({message:"Comenzando instalaci\xF3n ..."});await s.present();let n=window.connectors.apps.install(i);n.on("end",({message:r})=>{s.dismiss().then(()=>{r?window.alertController.create({header:"La aplicaci\xF3n no se pudo instalar",message:r,buttons:["Aceptar"]}).then(c=>c.present()):this.dispatchEvent(new CustomEvent("save"))})}),n.on("progress",r=>{s.message=`Subiendo ${r}%`}),n.start()}),e.click()}render(){return m`
      <ion-fab slot="fixed" vertical="bottom" horizontal="end">
        <ion-fab-button color="light" @click=${this.selectFile.bind(this)}>
          <ion-icon name="bag-add-outline"></ion-icon>
        </ion-fab-button>
      </ion-fab>
    `}};B=_([$("new-app")],B);var U=class extends u{constructor(){super(...arguments);this.permissionList=[];this.modal=E();this.PERMISSION_LIST={APP_LIST:"Lista de aplicaciones instaladas.",APP_LIST_BY_UUID:"Lista de aplicaciones instaladas filtradas por usuario.",INSTALL_APP:"Instalar aplicaciones.",UNINSTALL_APP:"Desinstalar aplicaciones.",ACCESS_SHARED_FILE_LIST:"Acceso a lista de archivos en carpeta compartida.",ACCESS_USER_FILE_LIST:"Acceso a lista de archivos en carpeta del usuario.",CREATE_SHARED_DIR:"Crear directorios en carpeta compartida.",CREATE_USER_DIR:"Crear directorios en carpeta del usuario.",UPLOAD_SHARED_FILE:"Subir archivos en carpeta compartida.",UPLOAD_USER_FILE:"Subir archivos en carpeta del usuario.",REMOVE_SHARED_FILES_AND_DIRECTORIES:"Eliminar archivos y/o directorios en carpeta compartida.",REMOVE_USER_FILES_AND_DIRECTORIES:"Eliminar archivos y/o directorios en carpeta del usuario.",ENABLE_PERMISSION:"Habilitar permisos de aplicaciones.",DISABLE_PERMISSION:"Deshabilitar permisos de aplicaciones.",PROFILE_INFO:"Acceso a la informaci\xF3n del perfil.",PROFILE_APP_LIST:"Lista de aplicaciones del asignadas al usuario.",UPDATE_PROFILE_INFO:"Actualizar informaci\xF3n del perfil.",UPDATE_PASSWORD:"Actualizar la contrase\xF1a.",ENABLE_SOURCE:"Habilita una fuente de recursos.",DISABLE_SOURCE:"Deshabilita una fuente de recursos.",USER_LIST:"Lista de usuarios.",USER_INFO:"Informaci\xF3n de un usuario.",CREATE_USER:"Crear usuarios",UPDATE_USER_INFO:"Actualizar la informaci\xF3n de un usuario.",DELETE_USER:"Eliminar usuarios",ASSIGN_APP_TO_USER:"Asignar una aplicaci\xF3n a un usuario.",UNASSIGN_APP_TO_USER:"Quitar la asignaci\xF3n de una aplicaci\xF3n a un usuario."};this.createRenderRoot=()=>this}async open(e){let i=await window.loadingController.create({message:"Cargando lista de permisos ..."});await i.present(),this.permissionList=await window.connectors.permissions.find({package_name:e}),await i.dismiss(),await this.modal.value?.present()}async setPermission(e,i){let s=await window.loadingController.create({message:i?"Concediendo permiso ...":"Revocando permiso ..."});await s.present(),i?await window.connectors.permissions.enable(e):await window.connectors.permissions.disable(e),await s.dismiss()}render(){return m`
      <style>
        ion-note {
          display: block;
        }
      </style>
      <ion-modal ${S(this.modal)}>
        <ion-header>
          <ion-toolbar>
            <ion-title>Permisos</ion-title>
            <ion-buttons slot="end">
              <ion-button @click=${()=>this.modal.value?.dismiss()}>
                <ion-icon slot="icon-only" name="close"></ion-icon>
              </ion-button>
            </ion-buttons>
          </ion-toolbar>
        </ion-header>
        <ion-content class="ion-padding">
          <ion-list inset>
            ${this.permissionList.length>0?"":m`
              <ion-item>
                <ion-label class="ion-text-center">No hay permisos</ion-label>
              </ion-item>
            `}
            ${this.permissionList.map(e=>m`
              <ion-item>
                <ion-toggle ?checked=${e.active} @ionChange=${()=>this.setPermission(e.id,!e.active)}>
                  <ion-label>${this.PERMISSION_LIST[e.api]||e.api}</ion-label>
                  <ion-note color="medium">${e.justification}</ion-note>
                </ion-toggle>
              </ion-item>
            `)}
          </ion-list>
        </ion-content>
      </ion-modal>
    `}};_([R()],U.prototype,"permissionList",2),U=_([$("app-permissions")],U);var M=class extends u{constructor(){super(...arguments);this.secureSourceList=[];this.modal=E()}async open(e){let i=await window.loadingController.create({message:"Cargando lista de fuentes seguras ..."});await i.present(),this.secureSourceList=await window.connectors.sources.find({package_name:e}),await i.dismiss(),await this.modal.value?.present()}async setSecure(e,i){let s=await window.loadingController.create({message:i?"Habilitando fuente ...":"Deshabilitando fuente ..."});await s.present(),i?await window.connectors.sources.enable(e):await window.connectors.sources.disable(e),await s.dismiss()}render(){return m`
      <ion-modal ${S(this.modal)}>
        <ion-header>
          <ion-toolbar>
            <ion-title>Fuentes seguras</ion-title>
            <ion-buttons slot="end">
              <ion-button @click=${()=>this.modal.value?.dismiss()}>
                <ion-icon slot="icon-only" name="close"></ion-icon>
              </ion-button>
            </ion-buttons>
          </ion-toolbar>
        </ion-header>
        <ion-content class="ion-padding">
          <ion-list inset>
            ${this.secureSourceList.length>0?"":m`
              <ion-item>
                <ion-label class="ion-text-center">No hay fuentes</ion-label>
              </ion-item>
            `}
            ${this.secureSourceList.map(e=>m`
              <ion-item>
                <ion-toggle ?checked=${e.active} @ionChange=${()=>this.setSecure(e.id,!e.active)}>
                  <ion-label>${e.source}</ion-label>
                  <ion-note color="medium">${e.type}</ion-note>
                </ion-toggle>
              </ion-item>
            `)}
          </ion-list>
        </ion-content>
      </ion-modal>
    `}};_([R()],M.prototype,"secureSourceList",2),M=_([$("app-sources")],M);var F=class extends u{constructor(){super(...arguments);this.appListElement=E();this.appPermissions=E();this.appSources=E();this.createRenderRoot=()=>this}render(){return m`
      <ion-app>
        <ion-header>
          <ion-toolbar>
            <ion-title>Apps</ion-title>
            <ion-buttons slot="end">
              <ion-button @click=${()=>this.appListElement.value?.loadApps()}>
                <ion-icon slot="icon-only" name="refresh"></ion-icon>
              </ion-button>
            </ion-buttons>
          </ion-toolbar>
        </ion-header>
        <ion-content class="ion-padding">
          <app-list
            ${S(this.appListElement)}
            @permissions=${e=>this.appPermissions.value?.open(e.detail.package_name)}
            @sources=${e=>this.appSources.value?.open(e.detail.package_name)}
          ></app-list>
          <app-permissions
            ${S(this.appPermissions)}
          ></app-permissions>
          <app-sources
            ${S(this.appSources)}
          ></app-sources>
          <new-app
            @save=${()=>this.appListElement.value?.loadApps()}
          ></new-app>
        </ion-content>
      </ion-app>
    `}};F=_([$("app-root")],F);document.addEventListener("onReady",async()=>{document.body.innerHTML="<app-root></app-root>"});export{F as default};
/*! Bundled license information:

@lit/reactive-element/css-tag.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/reactive-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/lit-html.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-element/lit-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/is-server.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/custom-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/directive-helpers.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/directive.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/async-directive.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/directives/ref.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/property.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/state.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
